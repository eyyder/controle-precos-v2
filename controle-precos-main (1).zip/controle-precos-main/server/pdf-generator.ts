import PDFDocument from "pdfkit";
import { getAllProducts, getAllPurchaseHistory } from "./db";

export async function generatePriceReportPDF(): Promise<Buffer> {
  const products = await getAllProducts();
  const history = await getAllPurchaseHistory();

  // Calcular estatísticas
  const totalProducts = products.length;
  const totalValue = products.reduce((sum, p) => sum + parseFloat(p.costPrice.toString()), 0);
  const totalQuantity = products.reduce((sum, p) => sum + (p.currentQuantity || 0), 0);

  const doc = new PDFDocument({
    size: "A4",
    margin: 40,
  });

  const chunks: Buffer[] = [];
  doc.on("data", (chunk: Buffer) => chunks.push(chunk));

  // Página 1: Resumo
  doc.fontSize(24).font("Helvetica-Bold").text("CONTROLE DE PREÇOS", { align: "center" });
  doc.fontSize(12).font("Helvetica").text("Relatório Completo de Produtos", { align: "center" });
  doc.fontSize(10).text(`Gerado em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}`, { align: "center" });
  doc.moveTo(40, doc.y + 5).lineTo(555, doc.y + 5).stroke();
  doc.moveDown(1);

  // Resumo
  doc.fontSize(14).font("Helvetica-Bold").text("RESUMO GERAL");
  doc.fontSize(10).font("Helvetica");
  doc.moveDown(0.5);

  const summaryData = [
    ["Métrica", "Valor"],
    ["Total de Produtos", totalProducts.toString()],
    ["Valor Total em Estoque (Custo)", `R$ ${totalValue.toFixed(2)}`],
    ["Quantidade Total em Estoque", totalQuantity.toString()],
  ];

  drawTable(doc, summaryData, [200, 150]);
  doc.moveDown(2);

  // Lista de Produtos - Múltiplas páginas
  const productsPerPage = 18;
  const totalPages = Math.ceil(products.length / productsPerPage);

  for (let pageNum = 0; pageNum < totalPages; pageNum++) {
    const startIdx = pageNum * productsPerPage;
    const endIdx = Math.min(startIdx + productsPerPage, products.length);
    const pageProducts = products.slice(startIdx, endIdx);

    if (pageNum > 0) {
      doc.addPage();
    }

    doc.fontSize(14).font("Helvetica-Bold").text(
      pageNum === 0 ? "PRODUTOS CADASTRADOS" : "PRODUTOS CADASTRADOS (continuação)",
      { underline: true }
    );
    doc.fontSize(9).font("Helvetica");
    doc.fontSize(8).text(`Página ${pageNum + 1} de ${totalPages} (Produtos ${startIdx + 1} a ${endIdx})`);
    doc.moveDown(0.5);

    const productData = [
      ["Produto", "Variação", "Custo", "Venda", "Qtd", "Margem"],
      ...pageProducts.map((product) => {
        const costPrice = parseFloat(product.costPrice.toString());
        const sellingPrice = parseFloat(product.sellingPrice.toString());
        const margin = sellingPrice > 0 ? ((sellingPrice - costPrice) / sellingPrice * 100).toFixed(1) : "0";

        return [
          product.name.substring(0, 18),
          product.variation ? product.variation.substring(0, 12) : "-",
          `R$ ${costPrice.toFixed(2)}`,
          `R$ ${sellingPrice.toFixed(2)}`,
          (product.currentQuantity || 0).toString(),
          `${margin}%`,
        ];
      }),
    ];

    drawTable(doc, productData, [110, 50, 65, 65, 35, 45]);
  }

  // Página final: Histórico de Compras
  doc.addPage();
  doc.fontSize(24).font("Helvetica-Bold").text("HISTÓRICO DE COMPRAS", { align: "center" });
  doc.fontSize(12).font("Helvetica").text("Últimas transações registradas no sistema", { align: "center" });
  doc.moveTo(40, doc.y + 5).lineTo(555, doc.y + 5).stroke();
  doc.moveDown(1);

  doc.fontSize(14).font("Helvetica-Bold").text("ÚLTIMAS 50 COMPRAS");
  doc.fontSize(9).font("Helvetica");
  doc.moveDown(0.5);

  const historyData = [
    ["Produto", "Data", "Custo Unit.", "Qtd", "Total"],
    ...history.slice(0, 50).map((record) => {
      const costPrice = parseFloat(record.costPrice.toString());
      const total = costPrice * record.quantity;
      const productName = products.find((p) => p.id === record.productId)?.name || `Produto #${record.productId}`;

      return [
        productName.substring(0, 22),
        new Date(record.purchaseDate).toLocaleDateString("pt-BR"),
        `R$ ${costPrice.toFixed(2)}`,
        record.quantity.toString(),
        `R$ ${total.toFixed(2)}`,
      ];
    }),
  ];

  drawTable(doc, historyData, [130, 75, 75, 45, 75]);

  doc.fontSize(8).text("Relatório confidencial - Controle de Preços", { align: "center" });

  return new Promise((resolve, reject) => {
    doc.on("end", () => {
      resolve(Buffer.concat(chunks));
    });
    doc.on("error", reject);
    doc.end();
  });
}

export async function generateProductDetailPDF(productId: number): Promise<Buffer> {
  const products = await getAllProducts();
  const product = products.find((p) => p.id === productId);

  if (!product) {
    throw new Error("Produto não encontrado");
  }

  const history = await getAllPurchaseHistory();
  const productHistory = history.filter((h) => h.productId === productId);

  const costPrice = parseFloat(product.costPrice.toString());
  const sellingPrice = parseFloat(product.sellingPrice.toString());
  const margin = sellingPrice > 0 ? ((sellingPrice - costPrice) / sellingPrice * 100).toFixed(1) : "0";
  const doc = new PDFDocument({
    size: "A4",
    margin: 40,
  });

  const chunks: Buffer[] = [];
  doc.on("data", (chunk: Buffer) => chunks.push(chunk));

  // Header
  doc.fontSize(24).font("Helvetica-Bold").text(product.name, { align: "center" });
  if (product.variation) {
    doc.fontSize(12).font("Helvetica").text(`Variação: ${product.variation}`, { align: "center" });
  }
  doc.fontSize(10).text(`Relatório gerado em ${new Date().toLocaleDateString("pt-BR")}`, { align: "center" });
  doc.moveTo(40, doc.y + 5).lineTo(555, doc.y + 5).stroke();
  doc.moveDown(1);

  // Informações do Produto
  doc.fontSize(14).font("Helvetica-Bold").text("INFORMAÇÕES DO PRODUTO");
  doc.fontSize(10).font("Helvetica");
  doc.moveDown(0.5);

  const productInfoData = [
    ["Campo", "Valor"],
    ["Preço de Custo", `R$ ${costPrice.toFixed(2)}`],
    ["Preço de Venda", `R$ ${sellingPrice.toFixed(2)}`],
    ["Margem de Lucro", `${margin}%`],
    ["Quantidade em Estoque", (product.currentQuantity || 0).toString()],
    ["Criado em", new Date(product.createdAt).toLocaleDateString("pt-BR")],
    ["Atualizado em", new Date(product.updatedAt).toLocaleDateString("pt-BR")],
  ];

  drawTable(doc, productInfoData, [200, 150]);
  doc.moveDown(1);

  // Histórico de Compras
  if (productHistory.length > 0) {
    doc.fontSize(14).font("Helvetica-Bold").text("HISTÓRICO DE COMPRAS");
    doc.fontSize(9).font("Helvetica");
    doc.moveDown(0.5);

    const historyData = [
      ["Data", "Custo Unit.", "Qtd", "Total", "Observações"],
      ...productHistory.map((record) => {
        const cost = parseFloat(record.costPrice.toString());
        const total = cost * record.quantity;

        return [
          new Date(record.purchaseDate).toLocaleDateString("pt-BR"),
          `R$ ${cost.toFixed(2)}`,
          record.quantity.toString(),
          `R$ ${total.toFixed(2)}`,
          record.notes?.substring(0, 20) || "-",
        ];
      }),
    ];

    drawTable(doc, historyData, [80, 80, 50, 80, 100]);
  }

  doc.fontSize(9).text("Relatório confidencial - Controle de Preços", { align: "center" });

  return new Promise((resolve, reject) => {
    doc.on("end", () => {
      resolve(Buffer.concat(chunks));
    });
    doc.on("error", reject);
    doc.end();
  });
}

// Função auxiliar para desenhar tabelas
function drawTable(
  doc: any,
  data: string[][],
  columnWidths: number[]
) {
  const startX = doc.page.margins.left;
  const startY = doc.y;
  const rowHeight = 18;

  // Desenhar header
  doc.fillColor("#0a1a2e").rect(startX, startY, columnWidths.reduce((a, b) => a + b, 0), rowHeight).fill();

  doc.fillColor("#ffffff").font("Helvetica-Bold").fontSize(8);
  let x = startX;
  data[0].forEach((cell, i) => {
    doc.text(cell, x + 3, startY + 4, { width: columnWidths[i] - 6, height: rowHeight - 8 });
    x += columnWidths[i];
  });

  // Desenhar linhas
  doc.fillColor("#000000").font("Helvetica").fontSize(8);
  let y = startY + rowHeight;

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const bgColor = i % 2 === 0 ? "#f5f5f5" : "#ffffff";

    doc.fillColor(bgColor).rect(startX, y, columnWidths.reduce((a, b) => a + b, 0), rowHeight).fill();
    doc.fillColor("#000000");

    x = startX;
    row.forEach((cell, j) => {
      doc.text(cell, x + 3, y + 3, { width: columnWidths[j] - 6, height: rowHeight - 6 });
      x += columnWidths[j];
    });

    y += rowHeight;

    // Se a tabela fica muito grande, adiciona nova página
    if (y > doc.page.height - 80) {
      doc.addPage();
      y = doc.page.margins.top;
    }
  }

  doc.y = y + 10;
}
