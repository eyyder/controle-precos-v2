import { COOKIE_NAME } from "@shared/const";
import { eq, like, desc } from "drizzle-orm";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getAllProducts,
  getProductById,
  searchProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  getPurchaseHistoryByProduct,
  getAllPurchaseHistory,
  createPurchaseRecord,
  getPriceAlerts,
  getUnreadPriceAlerts,
  createPriceAlert,
  markAlertAsRead,
  getAllCategories,
  createCategory,
  getAllProductsWithStats,
  getProductWithStats,
  getAllSuggestedMargins,
  getSuggestedMarginForProduct,
  upsertSuggestedMargin,
  deleteSuggestedMargin,
} from "./db";
import { generatePriceReportPDF, generateProductDetailPDF } from "./pdf-generator";
import { createBackup, listBackups, getBackup, deleteBackup, getBackupStats } from "./backup-service";
import {
  uploadBackupToGoogleDrive,
  listBackupsInGoogleDrive,
  deleteBackupFromGoogleDrive,
  getGoogleDriveAuthUrl,
  setGoogleDriveConfig,
  getGoogleDriveConfig,
} from "./google-drive-service";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ PRODUCTS ROUTER ============
  products: router({
    list: publicProcedure.query(async () => {
      return await getAllProducts();
    }),

    listWithStats: publicProcedure.query(async () => {
      return await getAllProductsWithStats();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getProductWithStats(input.id);
      }),

    search: publicProcedure
      .input(z.object({ term: z.string() }))
      .query(async ({ input }) => {
        return await searchProducts(input.term);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        categoryId: z.number().optional(),
        variation: z.string().optional(),
        costPrice: z.number().positive(),
        sellingPrice: z.number().positive(),
        currentQuantity: z.number().nonnegative().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createProduct(input);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        variation: z.string().optional(),
        costPrice: z.number().positive().optional(),
        sellingPrice: z.number().positive().optional(),
        currentQuantity: z.number().nonnegative().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;

        const existing = await getProductById(id);
        const updated = await updateProduct(id, data);

        const oldCostPrice = existing ? parseFloat(existing.costPrice.toString()) : undefined;
        if (existing && data.costPrice !== undefined && oldCostPrice !== data.costPrice) {
          await createPurchaseRecord({
            productId: id,
            costPrice: data.costPrice,
            sellingPrice: data.sellingPrice ?? parseFloat(existing.sellingPrice.toString()),
            quantity: 0,
            purchaseDate: new Date(),
            userId: ctx.user?.id || 0,
            notes: "Ajuste manual de preço",
          }, { skipProductUpdate: true });
        }

        return updated;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const success = await deleteProduct(input.id);
        return { success };
      }),
  }),

  // ============ PURCHASE HISTORY ROUTER ============
  purchaseHistory: router({
    listByProduct: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        return await getPurchaseHistoryByProduct(input.productId);
      }),

    listAll: publicProcedure.query(async () => {
      return await getAllPurchaseHistory();
    }),

    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        costPrice: z.number().positive(),
        sellingPrice: z.number().positive().optional(),
        quantity: z.number().int().nonnegative(),
        purchaseDate: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) throw new Error("User not authenticated");
        return await createPurchaseRecord({
          ...input,
          userId: ctx.user.id,
        });
      }),
  }),

  // ============ PRICE ALERTS ROUTER ============
  priceAlerts: router({
    list: publicProcedure.query(async () => {
      return await getPriceAlerts();
    }),

    listUnread: publicProcedure.query(async () => {
      return await getUnreadPriceAlerts();
    }),

    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        previousPrice: z.number().positive(),
        newPrice: z.number().positive(),
        variationPercentage: z.number(),
        alertThreshold: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createPriceAlert(input);
      }),

    markAsRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await markAlertAsRead(input.id);
        return { success: true };
      }),
  }),

  // ============ CATEGORIES ROUTER ============
  categories: router({
    list: publicProcedure.query(async () => {
      return await getAllCategories();
    }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createCategory(input.name, input.description);
      }),
  }),

  // ============ BACKUP ROUTER ============
  backup: router({
    list: publicProcedure.query(async () => {
      return listBackups();
    }),

    stats: publicProcedure.query(async () => {
      return getBackupStats();
    }),

    download: publicProcedure
      .input(z.object({ filename: z.string() }))
      .query(async ({ input }) => {
        const backup = getBackup(input.filename);
        if (!backup) {
          throw new Error("Backup nao encontrado");
        }
        return {
          success: true,
          filename: input.filename,
          data: JSON.stringify(backup),
        };
      }),

    delete: protectedProcedure
      .input(z.object({ filename: z.string() }))
      .mutation(async ({ input }) => {
        const success = deleteBackup(input.filename);
        return { success };
      }),

    createManual: protectedProcedure.mutation(async () => {
      const filename = await createBackup();
      return { success: true, filename };
    }),

    listGoogleDriveBackups: publicProcedure.query(async () => {
      try {
        return await listBackupsInGoogleDrive();
      } catch (error) {
        console.error("Erro ao listar backups do Google Drive:", error);
        return [];
      }
    }),

    deleteGoogleDriveBackup: protectedProcedure
      .input(z.object({ fileId: z.string() }))
      .mutation(async ({ input }) => {
        const success = await deleteBackupFromGoogleDrive(input.fileId);
        return { success };
      }),

    uploadToGoogleDrive: protectedProcedure
      .input(z.object({ filename: z.string() }))
      .mutation(async ({ input }) => {
        try {
          const { getBackupPath } = await import("./backup-service");
          const backupPath = getBackupPath(input.filename);
          const result = await uploadBackupToGoogleDrive(backupPath, input.filename);
          return { success: !!result, result };
        } catch (error) {
          console.error("Erro ao fazer upload para Google Drive:", error);
          return { success: false, error: "Erro ao fazer upload" };
        }
      }),
  }),

  // ============ SUGGESTED MARGINS ROUTER ============
  suggestedMargins: router({
    list: publicProcedure.query(async () => {
      return await getAllSuggestedMargins();
    }),

    suggest: publicProcedure
      .input(z.object({ productName: z.string() }))
      .query(async ({ input }) => {
        return await getSuggestedMarginForProduct(input.productName);
      }),

    upsert: protectedProcedure
      .input(z.object({
        categoryName: z.string().min(1),
        suggestedMargin: z.number().min(0).max(500),
        description: z.string().optional(),
        keywords: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await upsertSuggestedMargin(input);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const success = await deleteSuggestedMargin(input.id);
        return { success };
      }),
  }),

  // ============ PDF EXPORT ROUTER ============
  pdf: router({
    exportPriceReport: publicProcedure.query(async () => {
      const pdfBuffer = await generatePriceReportPDF();
      return {
        success: true,
        filename: `relatorio-precos-${new Date().toISOString().split('T')[0]}.pdf`,
        buffer: pdfBuffer.toString('base64'),
      };
    }),

    exportProductDetail: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }) => {
        const pdfBuffer = await generateProductDetailPDF(input.productId);
        return {
          success: true,
          filename: `produto-detalhes-${input.productId}-${new Date().toISOString().split('T')[0]}.pdf`,
          buffer: pdfBuffer.toString('base64'),
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
