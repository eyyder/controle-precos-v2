import { describe, expect, it, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock user for testing
const mockUser = {
  id: 1,
  openId: "test-user",
  email: "test@example.com",
  name: "Test User",
  loginMethod: "manus",
  role: "user" as const,
  createdAt: new Date(),
  updatedAt: new Date(),
  lastSignedIn: new Date(),
};

function createTestContext(user: typeof mockUser | null = mockUser): TrpcContext {
  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Products Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  let createdProductId: number;

  beforeAll(() => {
    caller = appRouter.createCaller(createTestContext());
  });

  it("should list all products", async () => {
    const result = await caller.products.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should create a new product", async () => {
    const result = await caller.products.create({
      name: "Test Product",
      variation: "1L",
      costPrice: 5.0,
      sellingPrice: 8.0,
      currentQuantity: 10,
    });

    expect(result).toBeDefined();
    expect(result?.name).toBe("Test Product");
    expect(result?.variation).toBe("1L");
    expect(result?.costPrice).toBe("5.00");
    expect(result?.sellingPrice).toBe("8.00");

    if (result?.id) {
      createdProductId = result.id;
    }
  });

  it("should get product by id", async () => {
    if (!createdProductId) {
      expect(true).toBe(true);
      return;
    }

    const result = await caller.products.getById({ id: createdProductId });
    expect(result).toBeDefined();
    expect(result?.id).toBe(createdProductId);
    expect(result?.name).toBe("Test Product");
  });

  it("should search products by term", async () => {
    const result = await caller.products.search({ term: "Test" });
    expect(Array.isArray(result)).toBe(true);
    // Should find at least our test product
    const found = result.find((p: any) => p.name === "Test Product");
    expect(found).toBeDefined();
  });

  it("should update product", async () => {
    if (!createdProductId) {
      expect(true).toBe(true);
      return;
    }

    const result = await caller.products.update({
      id: createdProductId,
      costPrice: 6.0,
      sellingPrice: 9.0,
      currentQuantity: 15,
    });

    expect(result).toBeDefined();
    expect(result?.costPrice).toBe("6.00");
    expect(result?.sellingPrice).toBe("9.00");
    expect(result?.currentQuantity).toBe(15);
  });
});

describe("Purchase History Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  let testProductId: number;

  beforeAll(async () => {
    caller = appRouter.createCaller(createTestContext());

    // Create a test product first
    const product = await caller.products.create({
      name: "Purchase Test Product",
      costPrice: 5.0,
      sellingPrice: 8.0,
    });

    if (product?.id) {
      testProductId = product.id;
    }
  });

  it("should list all purchase history", async () => {
    const result = await caller.purchaseHistory.listAll();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should create purchase record", async () => {
    if (!testProductId) {
      expect(true).toBe(true);
      return;
    }

    const result = await caller.purchaseHistory.create({
      productId: testProductId,
      costPrice: 5.0,
      sellingPrice: 8.0,
      quantity: 10,
      purchaseDate: new Date(),
      notes: "Test purchase",
    });

    expect(result).toBeDefined();
    expect(result?.productId).toBe(testProductId);
    expect(result?.quantity).toBe(10);
    expect(result?.notes).toBe("Test purchase");
  });

  it("should list purchase history by product", async () => {
    if (!testProductId) {
      expect(true).toBe(true);
      return;
    }

    const result = await caller.purchaseHistory.listByProduct({ productId: testProductId });
    expect(Array.isArray(result)).toBe(true);
    // Should have at least one record from our test
    expect(result.length).toBeGreaterThan(0);
  });
});

describe("Price Alerts Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createTestContext());
  });

  it("should list all price alerts", async () => {
    const result = await caller.priceAlerts.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should list unread price alerts", async () => {
    const result = await caller.priceAlerts.listUnread();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should create price alert", async () => {
    const result = await caller.priceAlerts.create({
      productId: 1,
      previousPrice: 5.0,
      newPrice: 5.5,
      variationPercentage: 10.0,
      alertThreshold: 10,
    });

    expect(result).toBeDefined();
    expect(result?.productId).toBe(1);
    expect(result?.variationPercentage).toBe("10.00");
    expect(result?.isRead).toBe(0);
  });
});

describe("Categories Router", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    caller = appRouter.createCaller(createTestContext());
  });

  it("should list all categories", async () => {
    const result = await caller.categories.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should create category", async () => {
    const result = await caller.categories.create({
      name: `Test Category ${Date.now()}`,
      description: "Test category description",
    });

    expect(result).toBeDefined();
    expect(result?.description).toBe("Test category description");
  });
});
