import { eq, like, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, products, purchaseHistory, priceAlerts, categories, Product, PurchaseHistory, PriceAlert, Category } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ PRODUCTS QUERIES ============

export async function getAllProducts(): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(products);
  } catch (error) {
    console.error("[Database] Failed to get all products:", error);
    return [];
  }
}

export async function getProductById(id: number): Promise<Product | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  try {
    const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get product by id:", error);
    return undefined;
  }
}

export async function searchProducts(searchTerm: string): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    const term = `%${searchTerm}%`;
    return await db.select().from(products).where(like(products.name, term)).limit(100);
  } catch (error) {
    console.error("[Database] Failed to search products:", error);
    return [];
  }
}

export async function createProduct(data: {
  name: string;
  categoryId?: number;
  variation?: string;
  costPrice: number;
  sellingPrice: number;
  currentQuantity?: number;
}): Promise<Product | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(products).values({
      name: data.name,
      categoryId: data.categoryId,
      variation: data.variation,
      costPrice: data.costPrice.toString(),
      sellingPrice: data.sellingPrice.toString(),
      currentQuantity: data.currentQuantity || 0,
      lastCostPrice: data.costPrice.toString(),
      lastPriceUpdateDate: new Date(),
    });
    const id = result[0]?.insertId;
    if (id) {
      const product = await getProductById(id);
      return product || null;
    }
    return null;
  } catch (error) {
    console.error("[Database] Failed to create product:", error);
    return null;
  }
}

export async function updateProduct(id: number, data: Partial<{
  name: string;
  variation: string;
  costPrice: number;
  sellingPrice: number;
  currentQuantity: number;
}>): Promise<Product | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const updateData: any = {};
    if (data.name !== undefined) {
      updateData.name = data.name;
    }
    if (data.variation !== undefined) {
      updateData.variation = data.variation || null;
    }
    if (data.costPrice !== undefined) {
      updateData.costPrice = data.costPrice.toString();
      updateData.lastCostPrice = data.costPrice.toString();
      updateData.lastPriceUpdateDate = new Date();
    }
    if (data.sellingPrice !== undefined) {
      updateData.sellingPrice = data.sellingPrice.toString();
    }
    if (data.currentQuantity !== undefined) {
      updateData.currentQuantity = data.currentQuantity;
    }
    updateData.updatedAt = new Date();

    await db.update(products).set(updateData).where(eq(products.id, id));
    const updated = await getProductById(id);
    return updated || null;
  } catch (error) {
    console.error("[Database] Failed to update product:", error);
    return null;
  }
}

export async function deleteProduct(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  try {
    const result = await db.delete(products).where(eq(products.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete product:", error);
    return false;
  }
}

// ============ PURCHASE HISTORY QUERIES ============

export async function getPurchaseHistoryByProduct(productId: number): Promise<PurchaseHistory[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(purchaseHistory)
      .where(eq(purchaseHistory.productId, productId))
      .orderBy(desc(purchaseHistory.purchaseDate));
  } catch (error) {
    console.error("[Database] Failed to get purchase history:", error);
    return [];
  }
}

export async function getAllPurchaseHistory(): Promise<PurchaseHistory[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(purchaseHistory).orderBy(desc(purchaseHistory.purchaseDate));
  } catch (error) {
    console.error("[Database] Failed to get all purchase history:", error);
    return [];
  }
}

export async function createPurchaseRecord(data: {
  productId: number;
  costPrice: number;
  sellingPrice?: number;
  quantity: number;
  purchaseDate: Date;
  userId: number;
  notes?: string;
}, options?: {
  skipProductUpdate?: boolean;
}): Promise<PurchaseHistory | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(purchaseHistory).values({
      productId: data.productId,
      costPrice: data.costPrice.toString(),
      sellingPrice: data.sellingPrice ? data.sellingPrice.toString() : null,
      quantity: data.quantity,
      purchaseDate: data.purchaseDate,
      userId: data.userId,
      notes: data.notes,
    });

    if (!options?.skipProductUpdate) {
      // Update product's current quantity and price
      const product = await getProductById(data.productId);
      if (product) {
        const newQuantity = (product.currentQuantity || 0) + data.quantity;
        await updateProduct(data.productId, {
          costPrice: data.costPrice,
          sellingPrice: data.sellingPrice || parseFloat(product.sellingPrice.toString()),
          currentQuantity: newQuantity,
        });
      }
    }

    const id = result[0]?.insertId;
    if (id) {
      const newRecord = await db.select().from(purchaseHistory).where(eq(purchaseHistory.id, id)).limit(1);
      return newRecord.length > 0 ? newRecord[0] : null;
    }
    return null;
  } catch (error) {
    console.error("[Database] Failed to create purchase record:", error);
    return null;
  }
}

// ============ PRICE ALERTS QUERIES ============

export async function getPriceAlerts(): Promise<PriceAlert[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(priceAlerts).orderBy(desc(priceAlerts.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get price alerts:", error);
    return [];
  }
}

export async function getUnreadPriceAlerts(): Promise<PriceAlert[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(priceAlerts).where(eq(priceAlerts.isRead, 0)).orderBy(desc(priceAlerts.createdAt));
  } catch (error) {
    console.error("[Database] Failed to get unread alerts:", error);
    return [];
  }
}

export async function createPriceAlert(data: {
  productId: number;
  previousPrice: number;
  newPrice: number;
  variationPercentage: number;
  alertThreshold?: number;
}): Promise<PriceAlert | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(priceAlerts).values({
      productId: data.productId,
      previousPrice: data.previousPrice.toString(),
      newPrice: data.newPrice.toString(),
      variationPercentage: data.variationPercentage.toString(),
      alertThreshold: data.alertThreshold ? data.alertThreshold.toString() : "10",
      isRead: 0,
    });

    const id = result[0]?.insertId;
    if (id) {
      const newAlert = await db.select().from(priceAlerts).where(eq(priceAlerts.id, id)).limit(1);
      return newAlert.length > 0 ? newAlert[0] : null;
    }
    return null;
  } catch (error) {
    console.error("[Database] Failed to create price alert:", error);
    return null;
  }
}

export async function markAlertAsRead(id: number): Promise<void> {
  const db = await getDb();
  if (!db) return;
  try {
    await db.update(priceAlerts).set({ isRead: 1 }).where(eq(priceAlerts.id, id));
  } catch (error) {
    console.error("[Database] Failed to mark alert as read:", error);
  }
}

// ============ CATEGORIES QUERIES ============

export async function getAllCategories(): Promise<Category[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(categories);
  } catch (error) {
    console.error("[Database] Failed to get categories:", error);
    return [];
  }
}

export async function createCategory(name: string, description?: string): Promise<Category | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const result = await db.insert(categories).values({
      name,
      description,
    });

    const id = result[0]?.insertId;
    if (id) {
      const newCat = await db.select().from(categories).where(eq(categories.id, id)).limit(1);
      return newCat.length > 0 ? newCat[0] : null;
    }
    return null;
  } catch (error) {
    console.error("[Database] Failed to create category:", error);
    return null;
  }
}


// ============ PRODUCT STATISTICS QUERIES ============

export interface ProductStats {
  minCostPrice: number;
  maxCostPrice: number;
  lastCostPriceValue: number;
  lastPurchaseDate: string;
  marginValue: number;
}

export async function getProductStats(productId: number): Promise<ProductStats | null> {
  const db = await getDb();
  if (!db) return null;
  
  try {
    const product = await getProductById(productId);
    if (!product) return null;

    const history = await db
      .select()
      .from(purchaseHistory)
      .where(eq(purchaseHistory.productId, productId))
      .orderBy(desc(purchaseHistory.purchaseDate));

    if (history.length === 0) {
      const costPrice = parseFloat(product.costPrice.toString());
      const sellingPrice = parseFloat(product.sellingPrice.toString());
      const margin = sellingPrice > 0 ? ((sellingPrice - costPrice) / sellingPrice) * 100 : 0;

      return {
        minCostPrice: costPrice,
        maxCostPrice: costPrice,
        lastCostPriceValue: costPrice,
        lastPurchaseDate: product.updatedAt.toISOString(),
        marginValue: margin,
      };
    }

    const costPrices = history.map((h) => parseFloat(h.costPrice.toString()));
    const minCostPrice = Math.min(...costPrices);
    const maxCostPrice = Math.max(...costPrices);
    const lastCostPrice = costPrices[0];
    const lastPurchaseDate = history[0].purchaseDate.toISOString();

    const sellingPrice = parseFloat(product.sellingPrice.toString());
    const margin = sellingPrice > 0 ? ((sellingPrice - lastCostPrice) / sellingPrice) * 100 : 0;

    return {
      minCostPrice,
      maxCostPrice,
      lastCostPriceValue: lastCostPrice,
      lastPurchaseDate,
      marginValue: margin,
    };
  } catch (error) {
    console.error("[Database] Failed to get product stats:", error);
    return null;
  }
}

export type ProductWithStats = Product & ProductStats;

export async function getProductWithStats(productId: number): Promise<ProductWithStats | null> {
  const product = await getProductById(productId);
  if (!product) return null;

  const stats = await getProductStats(productId);

  return {
    ...product,
    minCostPrice: stats?.minCostPrice ?? parseFloat(product.costPrice.toString()),
    maxCostPrice: stats?.maxCostPrice ?? parseFloat(product.costPrice.toString()),
    lastCostPriceValue: stats?.lastCostPriceValue ?? parseFloat(product.costPrice.toString()),
    lastPurchaseDate: stats?.lastPurchaseDate ?? product.updatedAt.toISOString(),
    marginValue: stats?.marginValue ?? 0,
  };
}

export async function getAllProductsWithStats(): Promise<any[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    const allProducts = await getAllProducts();
    const statsPromises = allProducts.map(async (product) => {
      const stats = await getProductStats(product.id);
      return {
        ...product,
        ...(stats || {
          minCostPrice: 0,
          maxCostPrice: 0,
          lastCostPriceValue: 0,
          lastPurchaseDate: new Date().toISOString(),
          marginValue: 0,
        }),
      };
    });

    return await Promise.all(statsPromises);
  } catch (error) {
    console.error("[Database] Failed to get products with stats:", error);
    return [];
  }
}

// ============ SUGGESTED MARGINS QUERIES ============

import { suggestedMargins, SuggestedMargin } from "../drizzle/schema";

export async function getAllSuggestedMargins(): Promise<SuggestedMargin[]> {
  const db = await getDb();
  if (!db) return [];
  try {
    return await db.select().from(suggestedMargins).orderBy(suggestedMargins.categoryName);
  } catch (error) {
    console.error("[Database] Failed to get suggested margins:", error);
    return [];
  }
}

export async function getSuggestedMarginForProduct(productName: string): Promise<SuggestedMargin | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    const allMargins = await db.select().from(suggestedMargins);
    const normalizedName = productName.toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    // Busca a categoria cujas keywords mais combinam com o nome do produto
    let bestMatch: SuggestedMargin | null = null;
    let bestScore = 0;

    for (const margin of allMargins) {
      if (!margin.keywords) continue;
      const keywords = margin.keywords.split(",").map(k =>
        k.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      );
      for (const keyword of keywords) {
        if (keyword.length >= 3 && normalizedName.includes(keyword)) {
          const score = keyword.length; // Prefere keywords mais longas (mais específicas)
          if (score > bestScore) {
            bestScore = score;
            bestMatch = margin;
          }
        }
      }
    }

    return bestMatch;
  } catch (error) {
    console.error("[Database] Failed to get suggested margin for product:", error);
    return null;
  }
}

export async function upsertSuggestedMargin(data: {
  categoryName: string;
  suggestedMargin: number;
  description?: string;
  keywords?: string;
}): Promise<SuggestedMargin | null> {
  const db = await getDb();
  if (!db) return null;
  try {
    await db.insert(suggestedMargins).values({
      categoryName: data.categoryName,
      suggestedMargin: data.suggestedMargin.toString(),
      description: data.description,
      keywords: data.keywords,
    }).onDuplicateKeyUpdate({
      set: {
        suggestedMargin: data.suggestedMargin.toString(),
        description: data.description,
        keywords: data.keywords,
      }
    });

    const result = await db.select().from(suggestedMargins)
      .where(eq(suggestedMargins.categoryName, data.categoryName))
      .limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to upsert suggested margin:", error);
    return null;
  }
}

export async function deleteSuggestedMargin(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  try {
    await db.delete(suggestedMargins).where(eq(suggestedMargins.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete suggested margin:", error);
    return false;
  }
}
