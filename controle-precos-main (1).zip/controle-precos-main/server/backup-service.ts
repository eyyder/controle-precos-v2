import { getAllProducts, getAllPurchaseHistory, getAllCategories, getPriceAlerts } from "./db";
import * as fs from "fs";
import * as path from "path";

export interface BackupData {
  version: string;
  timestamp: string;
  data: {
    products: any[];
    purchaseHistory: any[];
    categories: any[];
    priceAlerts: any[];
  };
}

// Diretório para armazenar backups
const BACKUP_DIR = path.join(process.cwd(), ".backups");

// Garantir que o diretório de backups existe
function ensureBackupDir() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
}

/**
 * Retorna o caminho completo de um backup
 */
export function getBackupPath(filename: string): string {
  return path.join(BACKUP_DIR, filename);
}

/**
 * Cria um backup completo dos dados
 */
export async function createBackup(): Promise<string> {
  ensureBackupDir();

  try {
    const [products, purchaseHistory, categories, priceAlerts] = await Promise.all([
      getAllProducts(),
      getAllPurchaseHistory(),
      getAllCategories(),
      getPriceAlerts(),
    ]);

    const backupData: BackupData = {
      version: "1.0",
      timestamp: new Date().toISOString(),
      data: {
        products,
        purchaseHistory,
        categories,
        priceAlerts,
      },
    };

    // Gerar nome do arquivo com data e hora
    const now = new Date();
    const dateStr = now.toISOString().split("T")[0];
    const timeStr = now.toISOString().split("T")[1].replace(/:/g, "-").substring(0, 8);
    const filename = `backup-${dateStr}-${timeStr}.json`;
    const filepath = path.join(BACKUP_DIR, filename);

    // Salvar backup
    fs.writeFileSync(filepath, JSON.stringify(backupData, null, 2));

    console.log(`[Backup] Backup criado com sucesso: ${filename}`);
    return filename;
  } catch (error) {
    console.error("[Backup] Erro ao criar backup:", error);
    throw error;
  }
}

/**
 * Lista todos os backups disponíveis
 */
export function listBackups(): Array<{
  filename: string;
  timestamp: string;
  size: number;
}> {
  ensureBackupDir();

  try {
    const files = fs.readdirSync(BACKUP_DIR);
    const backups = files
      .filter((f) => f.startsWith("backup-") && f.endsWith(".json"))
      .map((filename) => {
        const filepath = path.join(BACKUP_DIR, filename);
        const stats = fs.statSync(filepath);
        const data = JSON.parse(fs.readFileSync(filepath, "utf-8")) as BackupData;

        return {
          filename,
          timestamp: data.timestamp,
          size: stats.size,
        };
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    return backups;
  } catch (error) {
    console.error("[Backup] Erro ao listar backups:", error);
    return [];
  }
}

/**
 * Obtém um backup específico
 */
export function getBackup(filename: string): BackupData | null {
  ensureBackupDir();

  try {
    // Validar que o filename não contém caracteres perigosos
    if (!filename.match(/^backup-[\d\-]+\.json$/)) {
      throw new Error("Nome de arquivo inválido");
    }

    const filepath = path.join(BACKUP_DIR, filename);

    if (!fs.existsSync(filepath)) {
      return null;
    }

    const data = JSON.parse(fs.readFileSync(filepath, "utf-8")) as BackupData;
    return data;
  } catch (error) {
    console.error("[Backup] Erro ao obter backup:", error);
    return null;
  }
}

/**
 * Deleta um backup específico
 */
export function deleteBackup(filename: string): boolean {
  ensureBackupDir();

  try {
    // Validar que o filename não contém caracteres perigosos
    if (!filename.match(/^backup-[\d\-]+\.json$/)) {
      throw new Error("Nome de arquivo inválido");
    }

    const filepath = path.join(BACKUP_DIR, filename);

    if (!fs.existsSync(filepath)) {
      return false;
    }

    fs.unlinkSync(filepath);
    console.log(`[Backup] Backup deletado: ${filename}`);
    return true;
  } catch (error) {
    console.error("[Backup] Erro ao deletar backup:", error);
    return false;
  }
}

/**
 * Limpa backups antigos (mantém apenas os últimos N dias)
 */
export function cleanOldBackups(daysToKeep: number = 30): number {
  ensureBackupDir();

  try {
    const files = fs.readdirSync(BACKUP_DIR);
    const now = Date.now();
    const maxAge = daysToKeep * 24 * 60 * 60 * 1000; // em milissegundos

    let deletedCount = 0;

    files.forEach((filename) => {
      if (filename.startsWith("backup-") && filename.endsWith(".json")) {
        const filepath = path.join(BACKUP_DIR, filename);
        const stats = fs.statSync(filepath);
        const age = now - stats.mtimeMs;

        if (age > maxAge) {
          fs.unlinkSync(filepath);
          deletedCount++;
          console.log(`[Backup] Backup antigo deletado: ${filename}`);
        }
      }
    });

    return deletedCount;
  } catch (error) {
    console.error("[Backup] Erro ao limpar backups antigos:", error);
    return 0;
  }
}

/**
 * Obtém informações sobre o armazenamento de backups
 */
export function getBackupStats(): {
  totalBackups: number;
  totalSize: number;
  oldestBackup: string | null;
  newestBackup: string | null;
} {
  const backups = listBackups();

  let totalSize = 0;
  backups.forEach((backup) => {
    totalSize += backup.size;
  });

  return {
    totalBackups: backups.length,
    totalSize,
    oldestBackup: backups.length > 0 ? backups[backups.length - 1].filename : null,
    newestBackup: backups.length > 0 ? backups[0].filename : null,
  };
}
