import { google } from "googleapis";
import { Readable } from "stream";
import fs from "fs";
import path from "path";

const BACKUP_FOLDER_NAME = "Controle de Preços - Backups";
const SCOPES = ["https://www.googleapis.com/auth/drive.file"];

interface GoogleDriveConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
  refreshToken: string;
}

let googleDriveConfig: GoogleDriveConfig | null = null;

export function setGoogleDriveConfig(config: GoogleDriveConfig) {
  googleDriveConfig = config;
}

export function getGoogleDriveConfig(): GoogleDriveConfig | null {
  return googleDriveConfig;
}

async function getAuthClient() {
  if (!googleDriveConfig) {
    throw new Error("Google Drive config not set");
  }

  const oauth2Client = new google.auth.OAuth2(
    googleDriveConfig.clientId,
    googleDriveConfig.clientSecret,
    googleDriveConfig.redirectUri
  );

  oauth2Client.setCredentials({
    refresh_token: googleDriveConfig.refreshToken,
  });

  return oauth2Client;
}

async function getOrCreateBackupFolder() {
  const auth = await getAuthClient();
  const drive = google.drive({ version: "v3", auth });

  // Search for existing folder
  const res = await drive.files.list({
    q: `name='${BACKUP_FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    spaces: "drive",
    fields: "files(id, name)",
    pageSize: 1,
  });

  if (res.data.files && res.data.files.length > 0) {
    return res.data.files[0].id!;
  }

  // Create new folder
  const folderRes = await drive.files.create({
    requestBody: {
      name: BACKUP_FOLDER_NAME,
      mimeType: "application/vnd.google-apps.folder",
    },
    fields: "id",
  });

  return folderRes.data.id!;
}

export async function uploadBackupToGoogleDrive(
  backupFilePath: string,
  fileName: string
): Promise<{ fileId: string; webViewLink: string } | null> {
  try {
    if (!fs.existsSync(backupFilePath)) {
      console.error(`[Google Drive] Backup file not found: ${backupFilePath}`);
      return null;
    }

    const auth = await getAuthClient();
    const drive = google.drive({ version: "v3", auth });

    const folderId = await getOrCreateBackupFolder();

    const fileStream = fs.createReadStream(backupFilePath);
    const res = await drive.files.create({
      requestBody: {
        name: fileName,
        parents: [folderId],
        description: `Backup automático - ${new Date().toLocaleString("pt-BR")}`,
      },
      media: {
        mimeType: "application/json",
        body: fileStream,
      },
      fields: "id, webViewLink",
    });

    console.log(`[Google Drive] Backup uploaded: ${fileName} (ID: ${res.data.id})`);

    return {
      fileId: res.data.id!,
      webViewLink: res.data.webViewLink!,
    };
  } catch (error) {
    console.error("[Google Drive] Failed to upload backup:", error);
    return null;
  }
}

export async function listBackupsInGoogleDrive(): Promise<
  Array<{
    id: string;
    name: string;
    createdTime: string;
    size: string;
    webViewLink: string;
  }>
> {
  try {
    const auth = await getAuthClient();
    const drive = google.drive({ version: "v3", auth });

    const folderId = await getOrCreateBackupFolder();

    const res = await drive.files.list({
      q: `'${folderId}' in parents and trashed=false`,
      spaces: "drive",
      fields: "files(id, name, createdTime, size, webViewLink)",
      orderBy: "createdTime desc",
      pageSize: 100,
    });

    return (
      res.data.files?.map((file) => ({
        id: file.id!,
        name: file.name!,
        createdTime: file.createdTime!,
        size: file.size || "0",
        webViewLink: file.webViewLink!,
      })) || []
    );
  } catch (error) {
    console.error("[Google Drive] Failed to list backups:", error);
    return [];
  }
}

export async function deleteBackupFromGoogleDrive(fileId: string): Promise<boolean> {
  try {
    const auth = await getAuthClient();
    const drive = google.drive({ version: "v3", auth });

    await drive.files.delete({ fileId });

    console.log(`[Google Drive] Backup deleted: ${fileId}`);
    return true;
  } catch (error) {
    console.error("[Google Drive] Failed to delete backup:", error);
    return false;
  }
}

export async function downloadBackupFromGoogleDrive(
  fileId: string,
  outputPath: string
): Promise<boolean> {
  try {
    const auth = await getAuthClient();
    const drive = google.drive({ version: "v3", auth });

    const res = await drive.files.get(
      { fileId, alt: "media" },
      { responseType: "stream" }
    );

    const dest = fs.createWriteStream(outputPath);
    (res.data as Readable).pipe(dest);

    return new Promise((resolve, reject) => {
      dest.on("finish", () => {
        console.log(`[Google Drive] Backup downloaded: ${fileId}`);
        resolve(true);
      });
      dest.on("error", (err) => {
        console.error("[Google Drive] Failed to download backup:", err);
        reject(false);
      });
    });
  } catch (error) {
    console.error("[Google Drive] Failed to download backup:", error);
    return false;
  }
}

export function getGoogleDriveAuthUrl(): string {
  if (!googleDriveConfig) {
    throw new Error("Google Drive config not set");
  }

  const oauth2Client = new google.auth.OAuth2(
    googleDriveConfig.clientId,
    googleDriveConfig.clientSecret,
    googleDriveConfig.redirectUri
  );

  const authUrl = oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: SCOPES,
  });

  return authUrl;
}

export async function getRefreshTokenFromCode(code: string): Promise<string | null> {
  try {
    if (!googleDriveConfig) {
      throw new Error("Google Drive config not set");
    }

    const oauth2Client = new google.auth.OAuth2(
      googleDriveConfig.clientId,
      googleDriveConfig.clientSecret,
      googleDriveConfig.redirectUri
    );

    const { tokens } = await oauth2Client.getToken(code);
    return tokens.refresh_token || null;
  } catch (error) {
    console.error("[Google Drive] Failed to get refresh token:", error);
    return null;
  }
}
