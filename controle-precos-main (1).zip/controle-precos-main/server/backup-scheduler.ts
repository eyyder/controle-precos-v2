import { createBackup, cleanOldBackups, getBackupPath } from "./backup-service";
import { uploadBackupToGoogleDrive, getGoogleDriveConfig } from "./google-drive-service";

let backupInterval: NodeJS.Timeout | null = null;

/**
 * Inicia o agendador de backup diário
 * Por padrão, executa todos os dias às 2:00 AM
 */
export function startBackupScheduler(hourOfDay: number = 2, minuteOfDay: number = 0) {
  if (backupInterval) {
    console.log("[Backup Scheduler] Agendador já está em execução");
    return;
  }

  // Calcular tempo até a próxima execução
  const now = new Date();
  const nextRun = new Date();
  nextRun.setHours(hourOfDay, minuteOfDay, 0, 0);

  // Se já passou a hora de hoje, agendar para amanhã
  if (nextRun <= now) {
    nextRun.setDate(nextRun.getDate() + 1);
  }

  const timeUntilNextRun = nextRun.getTime() - now.getTime();

  console.log(
    `[Backup Scheduler] Próximo backup agendado para ${nextRun.toLocaleString("pt-BR")}`
  );

  // Agendar primeira execução
  const initialTimeout = setTimeout(() => {
    executeBackup();
    // Depois, agendar para executar a cada 24 horas
    backupInterval = setInterval(executeBackup, 24 * 60 * 60 * 1000);
  }, timeUntilNextRun);

  // Permitir que o processo não seja bloqueado
  initialTimeout.unref?.();
}

/**
 * Para o agendador de backup
 */
export function stopBackupScheduler() {
  if (backupInterval) {
    clearInterval(backupInterval);
    backupInterval = null;
    console.log("[Backup Scheduler] Agendador parado");
  }
}

/**
 * Executa o backup e limpeza
 */
async function executeBackup() {
  try {
    const now = new Date();
    console.log(`[Backup Scheduler] Iniciando backup em ${now.toLocaleString("pt-BR")}`);

    // Criar backup
    const filename = await createBackup();
    console.log(`[Backup Scheduler] Backup criado: ${filename}`);

    // Upload para Google Drive se configurado
    const gdConfig = getGoogleDriveConfig();
    if (gdConfig && gdConfig.refreshToken) {
      try {
        const backupPath = getBackupPath(filename);
        const result = await uploadBackupToGoogleDrive(backupPath, filename);
        if (result) {
          console.log(`[Backup Scheduler] Backup enviado para Google Drive: ${filename}`);
        }
      } catch (error) {
        console.error("[Backup Scheduler] Erro ao enviar backup para Google Drive:", error);
      }
    }

    // Limpar backups com mais de 30 dias
    const deletedCount = cleanOldBackups(30);
    if (deletedCount > 0) {
      console.log(`[Backup Scheduler] ${deletedCount} backup(s) antigo(s) deletado(s)`);
    }

    console.log("[Backup Scheduler] Backup concluído com sucesso");
  } catch (error) {
    console.error("[Backup Scheduler] Erro durante o backup:", error);
  }
}

/**
 * Executa um backup manual imediatamente
 */
export async function executeManualBackup(): Promise<string> {
  console.log("[Backup Scheduler] Iniciando backup manual");
  await executeBackup();
  // Importar listBackups do backup-service
  const { listBackups } = await import("./backup-service");
  const backups = listBackups();
  return backups.length > 0 ? backups[0].filename : "";
}
