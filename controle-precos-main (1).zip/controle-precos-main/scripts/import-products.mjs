import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import mysql from "mysql2/promise";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function importProducts() {
  const csvPath = path.join(__dirname, "../products_import.csv");

  if (!fs.existsSync(csvPath)) {
    console.error(`❌ Arquivo não encontrado: ${csvPath}`);
    process.exit(1);
  }

  // Create database connection
  const connection = await mysql.createConnection(process.env.DATABASE_URL);

  try {
    const csvContent = fs.readFileSync(csvPath, "utf-8");
    const lines = csvContent.split("\n").filter((line) => line.trim());

    // Skip header
    const dataLines = lines.slice(1);

    console.log(`📦 Iniciando importação de ${dataLines.length} produtos...`);

    let successCount = 0;
    let errorCount = 0;

    for (let i = 0; i < dataLines.length; i++) {
      const line = dataLines[i].trim();
      if (!line) continue;

      try {
        // Parse CSV line
        const parts = line.split(",");
        const nome = parts[0]?.trim() || "";
        const variacao = parts[1]?.trim() || null;
        const custo = parseFloat(parts[2] || "0");
        const precoVenda = parseFloat(parts[3] || "0");
        const quantidade = parseInt(parts[4] || "0");

        if (!nome || precoVenda <= 0) {
          console.warn(`⚠️  Linha ${i + 2}: Produto inválido - ${nome}`);
          errorCount++;
          continue;
        }

        // Insert product
        const query = `
          INSERT INTO products (name, variation, costPrice, sellingPrice, currentQuantity, lastCostPrice, createdAt, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
        `;

        await connection.execute(query, [
          nome,
          variacao,
          custo.toFixed(2),
          precoVenda.toFixed(2),
          quantidade,
          custo > 0 ? custo.toFixed(2) : null,
        ]);

        successCount++;

        // Progress indicator
        if ((i + 1) % 50 === 0) {
          console.log(`✅ ${i + 1}/${dataLines.length} produtos importados...`);
        }
      } catch (error) {
        errorCount++;
        console.error(`❌ Erro na linha ${i + 2}:`, error.message);
      }
    }

    console.log("\n" + "=".repeat(50));
    console.log(`✅ Importação concluída!`);
    console.log(`   Sucesso: ${successCount} produtos`);
    console.log(`   Erros: ${errorCount} produtos`);
    console.log("=".repeat(50));
  } finally {
    await connection.end();
  }

  process.exit(0);
}

importProducts().catch((error) => {
  console.error("❌ Erro fatal:", error);
  process.exit(1);
});
