export type MarginLevel = 'critical' | 'low' | 'acceptable' | 'good';

export interface MarginInfo {
  level: MarginLevel;
  label: string;
  percentage: number;
  minRecommended: number;
  idealMargin: number;
  multiplier: number;
  gap: number;
  message: string;
  source: string;
  categoryName: string;
}

// ============================================================
// REGRAS DE CATEGORIZAÇÃO PERSONALIZADAS — Gira Santana
// Fórmula de margem: ((venda - custo) / venda) × 100
// Multiplicador: preço de venda = custo × multiplicador
// ============================================================
const CATEGORY_RULES: {
  name: string;
  keywords: string[];
  multiplier: number;
  margin: number;       // margem real = 1 - (1/multiplier)
  minMargin: number;    // mínimo aceitável (80% da margem alvo)
  source: string;
}[] = [
  {
    name: "Cesta Básica",
    keywords: [
      "arroz", "feijao", "feijão", "leite", "oleo", "óleo", "acucar", "açúcar", "açucar",
      "cafe", "café", "sal", "macarrao", "macarrão", "farinha", "fuba", "fubá",
      "maizena", "achocolatado",
    ],
    multiplier: 1.40,
    margin: 28.5,
    minMargin: 20,
    source: "Gira Santana — Cesta Básica (chamariz, cliente sabe o preço)",
  },
  {
    name: "Bebidas",
    keywords: [
      "cerveja", "refrigerante", "coca", "guarana", "guaraná", "fanta", "sprite",
      "kuat", "suco", "agua", "água", "h2oh", "h2o", "gatorade", "energetico", "energético",
      "monster", "skol", "brahma", "heineken", "amstel", "eisenbahn", "crystal",
      "vinho", "cachaca", "cachaça", "vodka", "pinga", "groselha", "schweeppes", "soda",
    ],
    multiplier: 1.60,
    margin: 37.5,
    minMargin: 30,
    source: "Gira Santana — Bebidas (x1,60)",
  },
  {
    name: "Padaria",
    keywords: [
      "pao", "pão", "bolo", "sonho", "lingua de sogra", "língua de sogra",
      "sovadinho", "panquinho", "bisnaguinha", "panco", "broa", "torrada",
    ],
    multiplier: 1.60,
    margin: 37.5,
    minMargin: 30,
    source: "Gira Santana — Padaria (x1,60)",
  },
  {
    name: "Higiene Pessoal",
    keywords: [
      "absorvente", "algodao", "algodão", "sabonete", "pasta de dente",
      "escova de dente", "shampoo", "desodorante", "cotonete", "hidratante",
      "locao", "loção", "dental", "oral-b", "palmolive", "protex", "gillette",
      "kit hidra", "kit shampoo", "kit seda", "herbissimo", "herbíssimo",
      "giovanna", "above", "salon line",
    ],
    multiplier: 1.75,
    margin: 42.8,
    minMargin: 35,
    source: "Gira Santana — Higiene Pessoal (x1,75)",
  },
  {
    name: "Limpeza",
    keywords: [
      "sabao", "sabão", "omo", "tixan", "detergente", "limpol", "ype", "ypê",
      "amaciante", "uau", "agua sanitaria", "água sanitária", "desinfetante",
      "esponja", "bombril", "assolan", "qboa", "veja", "cif", "tira-limo",
      "azulim", "saco de lixo", "sanitaria", "sanitária", "sbp", "inseticida",
      "frebom", "bufalo",
    ],
    multiplier: 1.75,
    margin: 42.8,
    minMargin: 35,
    source: "Gira Santana — Limpeza (x1,75)",
  },
  {
    name: "Laticínios e Congelados",
    keywords: [
      "queijo", "mussarela", "mucarela", "muçarela", "presunto", "apresuntado",
      "mortadela", "linguica", "linguiça", "linguicinha", "linguiçinha", "salame",
      "calabresa", "hamburguer", "hambúrguer", "nuggets", "empanado", "steak",
      "salsicha", "sorvete", "picole", "picolé", "geladinho", "requeijao", "requeijão",
      "manteiga", "margarina", "qualy", "iogurte", "danone", "yakult", "chamyto",
      "pirakids", "creme de leite", "fatiado",
    ],
    multiplier: 1.90,
    margin: 47.3,
    minMargin: 38,
    source: "Gira Santana — Laticínios/Congelados (x1,90 — custo de energia)",
  },
  {
    name: "Impulso e Guloseimas",
    keywords: [
      "bala", "chiclete", "chocolate", "bombom", "fini", "bis", "kitkat",
      "salgadinho", "fofura", "torcida", "cheetos", "doritos", "ruffles", "rufles",
      "doce", "gelatina", "talento", "trento", "gomutcho", "pirulito", "halls",
      "mentos", "trident", "havaianas", "isqueiro", "wafer", "negresco",
      "prestigio", "prestígio", "stiksy", "traquinas", "pipoca", "pringles",
      "palha", "m&m", "mini oreo", "marilan", "passatempo", "bono", "rosquinha",
      "piraque", "piraquê", "kellogs", "kellogg", "torrada bauducco",
      "clube social", "mini teens", "dueto predilecta",
    ],
    multiplier: 2.25,
    margin: 55.5,
    minMargin: 45,
    source: "Gira Santana — Impulso/Guloseimas (x2,25 — compra por impulso)",
  },
  {
    name: "Cigarros",
    keywords: [
      "cigarro", "marlboro", "rothmans", "dunhill", "carlton", "winston",
      "palheiro", "chesterfield",
    ],
    multiplier: 1.10,
    margin: 9.0,
    minMargin: 7,
    source: "Gira Santana — Cigarros (margem tabelada pelo fabricante)",
  },
];

const DEFAULT_RULE = {
  name: "Geral",
  multiplier: 1.80,
  margin: 44.4,
  minMargin: 35,
  source: "Gira Santana — Regra Padrão (x1,80)",
};

function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s&-]/g, " ")
    .trim();
}

export function getCategoryRule(productName: string) {
  const n = normalize(productName);
  let bestMatch: typeof CATEGORY_RULES[0] | null = null;
  let bestScore = 0;

  for (const rule of CATEGORY_RULES) {
    for (const kw of rule.keywords) {
      const normKw = normalize(kw);
      if (normKw.length >= 3 && n.includes(normKw)) {
        const score = normKw.length;
        if (score > bestScore) {
          bestScore = score;
          bestMatch = rule;
        }
      }
    }
  }

  return bestMatch ?? { ...DEFAULT_RULE, keywords: [] };
}

export function getSuggestedSellingPrice(costPrice: number, productName: string): number {
  const rule = getCategoryRule(productName);
  return Math.round(costPrice * rule.multiplier * 100) / 100;
}

export function evaluateMargin(costPrice: number, sellingPrice: number, productName?: string): MarginInfo {
  const rule = productName ? getCategoryRule(productName) : { ...DEFAULT_RULE, keywords: [] };

  if (costPrice <= 0 || sellingPrice <= 0) {
    return {
      level: 'critical',
      label: 'Inválido',
      percentage: 0,
      minRecommended: rule.minMargin,
      idealMargin: rule.margin,
      multiplier: rule.multiplier,
      gap: rule.minMargin,
      message: 'Preço de custo ou venda inválido.',
      source: rule.source,
      categoryName: rule.name,
    };
  }

  const margin = ((sellingPrice - costPrice) / sellingPrice) * 100;
  const { minMargin, margin: idealMargin, multiplier, source, name: categoryName } = rule;
  const gap = Math.max(0, minMargin - margin);

  let level: MarginLevel;
  let label: string;
  let message: string;

  if (margin < minMargin * 0.7) {
    level = 'critical';
    label = 'Crítica';
    message = `Margem de ${margin.toFixed(1)}% está muito abaixo do mínimo (${minMargin}%) para ${categoryName}. Preço sugerido: R$ ${getSuggestedSellingPrice(costPrice, productName ?? "").toFixed(2)}.`;
  } else if (margin < minMargin) {
    level = 'low';
    label = 'Baixa';
    message = `Margem de ${margin.toFixed(1)}% está abaixo do mínimo de ${minMargin}% para ${categoryName}. Preço sugerido: R$ ${getSuggestedSellingPrice(costPrice, productName ?? "").toFixed(2)}.`;
  } else if (margin < idealMargin) {
    level = 'acceptable';
    label = 'Aceitável';
    message = `Margem de ${margin.toFixed(1)}% está acima do mínimo (${minMargin}%), mas abaixo do ideal (${idealMargin.toFixed(1)}%) para ${categoryName}.`;
  } else {
    level = 'good';
    label = 'Boa';
    message = `Margem de ${margin.toFixed(1)}% está dentro do ideal para ${categoryName} (meta: ${idealMargin.toFixed(1)}%).`;
  }

  return {
    level,
    label,
    percentage: Math.round(margin * 100) / 100,
    minRecommended: minMargin,
    idealMargin,
    multiplier,
    gap,
    message,
    source,
    categoryName,
  };
}

export function getMarginColor(level: MarginLevel): string {
  switch (level) {
    case 'critical':   return 'text-red-500';
    case 'low':        return 'text-orange-400';
    case 'acceptable': return 'text-yellow-400';
    case 'good':       return 'text-green-500';
    default:           return 'text-gray-400';
  }
}

export function getMarginBg(level: MarginLevel): string {
  switch (level) {
    case 'critical':   return 'bg-red-500/10 border-red-500/30';
    case 'low':        return 'bg-orange-400/10 border-orange-400/30';
    case 'acceptable': return 'bg-yellow-400/10 border-yellow-400/30';
    case 'good':       return 'bg-green-500/10 border-green-500/30';
    default:           return 'bg-gray-400/10 border-gray-400/30';
  }
}
