const marginThresholds = {
  "cereals": {
    "min": 0.00,
    "max": 0.10
  },
  "dairy": {
    "min": 0.08,
    "max": 0.15
  },
  "meat": {
    "min": 0.12,
    "max": 0.20
  },
  "fruits": {
    "min": 0.05,
    "max": 0.15
  },
  "vegetables": {
    "min": 0.05,
    "max": 0.15
  },
  "frozen": {
    "min": 0.10,
    "max": 0.18
  },
  "beverages": {
    "min": 0.10,
    "max": 0.20
  },
};

export default marginThresholds;
