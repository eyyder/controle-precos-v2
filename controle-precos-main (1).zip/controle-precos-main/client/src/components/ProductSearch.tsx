import { useState, useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";
import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface ProductSearchProps {
  onSelectProduct?: (productId: number) => void;
  onSelectProductData?: (product: any) => void;
}

export default function ProductSearch({ onSelectProduct, onSelectProductData }: ProductSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const { data: products = [] } = trpc.products.list.useQuery();
  const { data: searchResults = [] } = trpc.products.search.useQuery(
    { term: searchTerm },
    { enabled: searchTerm.length > 0 }
  );

  const displayResults = searchTerm.length > 0 ? searchResults : [];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        searchInputRef.current &&
        !searchInputRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) {
      if (e.key === "ArrowDown" || e.key === "Enter") {
        setIsOpen(true);
      }
      return;
    }

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        setSelectedIndex((prev) =>
          prev < displayResults.length - 1 ? prev + 1 : prev
        );
        break;
      case "ArrowUp":
        e.preventDefault();
        setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1));
        break;
      case "Enter":
        e.preventDefault();
        if (selectedIndex >= 0 && displayResults[selectedIndex]) {
          selectProduct(displayResults[selectedIndex]);
        }
        break;
      case "Escape":
        setIsOpen(false);
        setSelectedIndex(-1);
        break;
    }
  };

  const selectProduct = (product: any) => {
    if (onSelectProduct) {
      onSelectProduct(product.id);
    }
    if (onSelectProductData) {
      onSelectProductData(product);
    }
    setSearchTerm("");
    setIsOpen(false);
    setSelectedIndex(-1);
  };

  const handleClear = () => {
    setSearchTerm("");
    setIsOpen(false);
    setSelectedIndex(-1);
    searchInputRef.current?.focus();
  };

  return (
    <div className="relative w-full">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-accent pointer-events-none" />
        <Input
          ref={searchInputRef}
          type="text"
          placeholder="Buscar produto (ex: Coca, Leite)..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
            setSelectedIndex(-1);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          className="pl-10 pr-10 py-3 text-base bg-input border-2 border-accent rounded-lg text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
        />
        {searchTerm && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClear}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 h-auto p-1"
          >
            <X className="w-5 h-5" />
          </Button>
        )}
      </div>

      {isOpen && displayResults.length > 0 && (
        <div
          ref={dropdownRef}
          className="absolute top-full left-0 right-0 mt-2 bg-card border-2 border-accent rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto"
        >
          {displayResults.map((product: any, index: number) => (
            <button
              key={product.id}
              onClick={() => selectProduct(product)}
              className={`w-full px-4 py-3 text-left border-b border-border last:border-b-0 transition-colors ${
                index === selectedIndex
                  ? "bg-accent text-accent-foreground"
                  : "bg-card text-foreground hover:bg-muted"
              }`}
            >
              <div className="flex justify-between items-start gap-2">
                <div className="flex-1">
                  <div className="font-semibold text-sm">
                    {product.name}
                    {product.variation && ` (${product.variation})`}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Custo: R$ {parseFloat(product.costPrice).toFixed(2)} | Venda: R$ {parseFloat(product.sellingPrice).toFixed(2)}
                  </div>
                </div>
                <div className="text-xs bg-muted px-2 py-1 rounded text-muted-foreground">
                  Qtd: {product.currentQuantity || 0}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {isOpen && searchTerm && displayResults.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-card border-2 border-accent rounded-lg p-4 text-center text-muted-foreground">
          Nenhum produto encontrado
        </div>
      )}
    </div>
  );
}
