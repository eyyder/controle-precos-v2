import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

interface PdfExportButtonProps {
  type: "report" | "product";
  productId?: number;
  label?: string;
}

export default function PdfExportButton({
  type,
  productId,
  label = "Baixar PDF",
}: PdfExportButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const exportReportMutation = trpc.pdf.exportPriceReport.useQuery(
    undefined,
    { enabled: false }
  );

  const exportProductMutation = trpc.pdf.exportProductDetail.useQuery(
    { productId: productId || 0 },
    { enabled: false }
  );

  const handleDownload = async () => {
    setIsLoading(true);
    try {
      let data;

      if (type === "report") {
        const result = await exportReportMutation.refetch();
        data = result.data;
      } else {
        if (!productId) {
          toast.error("ID do produto não fornecido");
          return;
        }
        const result = await exportProductMutation.refetch();
        data = result.data;
      }

      if (!data || !data.success) {
        toast.error("Erro ao gerar PDF");
        return;
      }

      // Converter base64 para blob
      const binaryString = atob(data.buffer);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/pdf" });

      // Criar link de download
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = data.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success("PDF baixado com sucesso!");
    } catch (error) {
      console.error("Erro ao baixar PDF:", error);
      toast.error("Erro ao baixar PDF");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Button
      onClick={handleDownload}
      disabled={isLoading}
      className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold border-2 border-accent rounded-lg flex items-center gap-2"
      size="sm"
    >
      {isLoading ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          Gerando...
        </>
      ) : (
        <>
          <Download className="w-4 h-4" />
          {label}
        </>
      )}
    </Button>
  );
}
