import { AlertTriangle, TrendingUp, CheckCircle2, XCircle } from "lucide-react";
import { evaluateMargin, getMarginBg, getMarginColor, type MarginLevel } from "@/lib/marginEvaluator";

interface MarginWarningProps {
  productName: string;
  costPrice: number;
  sellingPrice: number;
  /** Modo compacto para listas/busca */
  compact?: boolean;
}

function MarginIcon({ level, className }: { level: MarginLevel; className?: string }) {
  switch (level) {
    case "critical": return <XCircle className={className} />;
    case "low":      return <AlertTriangle className={className} />;
    case "acceptable": return <TrendingUp className={className} />;
    case "good":     return <CheckCircle2 className={className} />;
  }
}

export default function MarginWarning({ productName, costPrice, sellingPrice, compact = false }: MarginWarningProps) {
  const evaluation = evaluateMargin(costPrice, sellingPrice, productName);

  // Não mostrar nada se a margem está boa
  if (evaluation.level === "good") return null;
  // No modo compacto, só mostrar se for crítico ou baixo
  if (compact && evaluation.level === "acceptable") return null;

  const colorClass = getMarginColor(evaluation.level);
  const bgClass = getMarginBg(evaluation.level);

  if (compact) {
    // Versão compacta: apenas um badge/ícone inline
    return (
      <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${bgClass} ${colorClass}`}>
        <MarginIcon level={evaluation.level} className="w-3 h-3" />
        {evaluation.level === "critical" ? "Margem crítica" : `Abaixo de ${evaluation.minRecommended.toFixed(0)}%`}
      </span>
    );
  }

  // Versão completa: card com explicação
  return (
    <div className={`rounded-xl border p-4 ${bgClass}`}>
      <div className="flex items-start gap-3">
        <MarginIcon level={evaluation.level} className={`w-5 h-5 flex-shrink-0 mt-0.5 ${colorClass}`} />
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-bold mb-1 ${colorClass}`}>
            {evaluation.level === "critical" ? "⚠️ Margem Crítica" : "⚠️ Margem Abaixo do Recomendado"}
          </p>
          <p className="text-xs text-muted-foreground leading-relaxed mb-2">
            {evaluation.message}
          </p>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground uppercase">Mínimo recomendado</p>
              <p className={`text-sm font-bold ${colorClass}`}>{evaluation.minRecommended.toFixed(0)}%</p>
            </div>
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground uppercase">Margem ideal</p>
              <p className="text-sm font-bold text-foreground">{evaluation.idealMargin.toFixed(0)}%</p>
            </div>
            {evaluation.gap > 0 && (
              <div className="text-center">
                <p className="text-[10px] text-muted-foreground uppercase">Falta</p>
                <p className={`text-sm font-bold ${colorClass}`}>{evaluation.gap.toFixed(1)} p.p.</p>
              </div>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground mt-2">Fonte: {evaluation.source}</p>
        </div>
      </div>
    </div>
  );
}
