import { useState, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Search, X, TrendingUp, TrendingDown, Minus } from "lucide-react";
import MarginWarning from "@/components/MarginWarning";

interface QuickSearchProps {
  onSelectProduct: (productId: number) => void;
}

// Normaliza texto: remove acentos, converte para minúsculo
function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

// Verifica se o termo bate com o produto (busca fuzzy)
function matchesSearch(product: { name: string; variation?: string | null }, term: string): boolean {
  if (!term) return false;
  const normalizedTerm = normalize(term);
  const normalizedName = normalize(product.name);
  const normalizedVariation = product.variation ? normalize(product.variation) : "";
  return normalizedName.includes(normalizedTerm) || normalizedVariation.includes(normalizedTerm);
}

export default function QuickSearch({ onSelectProduct }: QuickSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const { data: rawProducts = [] } = trpc.products.listWithStats.useQuery();
  const allProducts = rawProducts as any[];

  // Foca automaticamente ao carregar
  useEffect(() => {
    const timer = setTimeout(() => {
      inputRef.current?.focus();
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  const results = searchTerm.length >= 1
    ? (allProducts as Array<{ id: number; name: string; variation?: string | null; costPrice: string; sellingPrice: string; lastCostPrice?: string | null; minCostPrice?: number; maxCostPrice?: number; marginValue?: number }>)
        .filter((p) => matchesSearch(p, searchTerm))
        .slice(0, 20)
    : [];

  const handleClear = () => {
    setSearchTerm("");
    inputRef.current?.focus();
  };

  const handleSelect = (productId: number) => {
    setSearchTerm("");
    onSelectProduct(productId);
  };

  return (
    <div className="w-full">
      {/* Campo de busca */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-accent pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          inputMode="text"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          placeholder="Digite o nome do produto..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-card border-2 border-accent rounded-xl pl-12 pr-12 py-4 text-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
        />
        {searchTerm && (
          <button
            onClick={handleClear}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Resultados */}
      {searchTerm.length >= 1 && (
        <div>
          {results.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-base">Nenhum produto encontrado para</p>
              <p className="font-semibold text-foreground mt-1">"{searchTerm}"</p>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground mb-3">
                {results.length} produto{results.length !== 1 ? "s" : ""} encontrado{results.length !== 1 ? "s" : ""}
              </p>
              {results.map((product) => {
                const cost = parseFloat(product.costPrice);
                const selling = parseFloat(product.sellingPrice);
                const lastCost = product.lastCostPrice ? parseFloat(product.lastCostPrice) : null;
                const margin = selling > 0 ? ((selling - cost) / selling) * 100 : 0;
                const variation = lastCost && lastCost !== cost
                  ? ((cost - lastCost) / lastCost) * 100
                  : null;

                return (
                  <button
                    key={product.id}
                    onClick={() => handleSelect(product.id)}
                    className="w-full bg-card border border-accent/30 hover:border-accent rounded-xl p-4 text-left transition-all active:scale-[0.98]"
                  >
                    {/* Nome do produto */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-foreground text-base leading-tight">
                          {product.name}
                        </p>
                        {product.variation && (
                          <p className="text-xs text-muted-foreground mt-0.5">{product.variation}</p>
                        )}
                      </div>
                      {variation !== null && (
                        <div className={`flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg flex-shrink-0 ${
                          variation > 0
                            ? "bg-destructive/15 text-destructive"
                            : variation < 0
                            ? "bg-green-500/15 text-green-500"
                            : "bg-muted text-muted-foreground"
                        }`}>
                          {variation > 0 ? <TrendingUp className="w-3 h-3" /> : variation < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                          {variation > 0 ? "+" : ""}{variation.toFixed(1)}%
                        </div>
                      )}
                    </div>

                    {/* Preços */}
                    <div className="grid grid-cols-3 gap-2 mb-2">
                      <div className="bg-background rounded-lg px-3 py-2 text-center">
                        <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-0.5">Custo atual</p>
                        <p className="text-sm font-bold text-foreground">R$ {cost.toFixed(2)}</p>
                      </div>
                      <div className="bg-accent/10 rounded-lg px-3 py-2 text-center">
                        <p className="text-[10px] text-accent uppercase font-semibold mb-0.5">Venda</p>
                        <p className="text-sm font-bold text-accent">R$ {selling.toFixed(2)}</p>
                      </div>
                      <div className={`rounded-lg px-3 py-2 text-center ${margin >= 20 ? "bg-green-500/10" : "bg-muted"}`}>
                        <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-0.5">Margem</p>
                        <p className={`text-sm font-bold ${margin >= 20 ? "text-green-500" : "text-foreground"}`}>
                          {margin.toFixed(1)}%
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mb-2 text-xs text-muted-foreground">
                      <div className="bg-background/50 rounded-lg px-2 py-1 text-center">
                        <p>Mín pago</p>
                        <p className="font-semibold text-foreground">R$ {(product.minCostPrice ?? cost).toFixed(2)}</p>
                      </div>
                      <div className="bg-background/50 rounded-lg px-2 py-1 text-center">
                        <p>Máx pago</p>
                        <p className="font-semibold text-foreground">R$ {(product.maxCostPrice ?? cost).toFixed(2)}</p>
                      </div>
                    </div>
                    {/* Alerta compacto de margem */}
                    <MarginWarning
                      productName={product.name}
                      costPrice={cost}
                      sellingPrice={selling}
                      compact
                    />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Estado inicial: dica de uso */}
      {!searchTerm && (
        <div className="text-center py-10">
          <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Search className="w-8 h-8 text-accent/50" />
          </div>
          <p className="text-muted-foreground text-sm">
            Digite o nome do produto para consultar
          </p>
          <p className="text-muted-foreground/60 text-xs mt-1">
            Funciona sem acento e sem maiúscula
          </p>
        </div>
      )}
    </div>
  );
}
