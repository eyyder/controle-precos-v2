import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import { Home as HomeIcon } from "lucide-react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import ProductDetail from "./pages/ProductDetail";
import PurchaseHistory from "./pages/PurchaseHistory";
import PriceAlerts from "./pages/PriceAlerts";
import NewProduct from "./pages/NewProduct";
import ImportProducts from "./pages/ImportProducts";
import Backups from "./pages/Backups";
import GoogleDriveBackups from "./pages/GoogleDriveBackups";
import ProductsList from "./pages/ProductsList";
import EditProduct from "./pages/EditProduct";
import SuggestedMargins from "./pages/SuggestedMargins";
import MarginReport from "./pages/MarginReport";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/produto/:id" component={ProductDetail} />
      <Route path="/historico" component={PurchaseHistory} />
      <Route path="/alertas" component={PriceAlerts} />
      <Route path="/novo-produto" component={NewProduct} />
      <Route path="/importar" component={ImportProducts} />
      <Route path="/backups" component={Backups} />
      <Route path="/backups/google-drive" component={GoogleDriveBackups} />
      <Route path="/listagem" component={ProductsList} />
      <Route path="/edit-product/:id" component={EditProduct} />
      <Route path="/produto/:id/editar" component={EditProduct} />
      <Route path="/margens-sugeridas" component={SuggestedMargins} />
      <Route path="/relatorio-margens" component={MarginReport} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [, setLocation] = useLocation();

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
          <button
            onClick={() => setLocation("/")}
            title="Ir para Home"
            className="fixed bottom-5 right-5 z-50 h-12 w-12 rounded-full bg-accent text-accent-foreground shadow-lg hover:bg-accent/90 transition-colors flex items-center justify-center"
          >
            <HomeIcon className="h-5 w-5" />
          </button>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
