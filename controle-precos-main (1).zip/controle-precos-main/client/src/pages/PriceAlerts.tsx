import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, AlertCircle, TrendingUp, TrendingDown, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function PriceAlerts() {
  const [, setLocation] = useLocation();
  const { data: alerts = [], refetch } = trpc.priceAlerts.list.useQuery();
  const markAsReadMutation = trpc.priceAlerts.markAsRead.useMutation();

  const handleMarkAsRead = async (alertId: number) => {
    try {
      await markAsReadMutation.mutateAsync({ id: alertId });
      refetch();
      toast.success("Alerta marcado como lido");
    } catch (error) {
      toast.error("Erro ao marcar alerta");
    }
  };

  const unreadAlerts = alerts.filter((a: any) => a.isRead === 0);
  const readAlerts = alerts.filter((a: any) => a.isRead === 1);

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b-2 border-accent sticky top-0 z-40">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-accent hover:bg-muted"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-foreground">ALERTAS DE PREÇO</h1>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        {alerts.length === 0 ? (
          <Card className="bg-card border-2 border-border p-8 rounded-lg text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-foreground font-semibold mb-2">Nenhum alerta de preço</p>
            <p className="text-muted-foreground text-sm">
              Alertas serão gerados quando o preço de um produto variar mais de 10%
            </p>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Unread Alerts */}
            {unreadAlerts.length > 0 && (
              <div>
                <h2 className="text-sm font-bold text-destructive mb-3 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  ALERTAS NÃO LIDOS ({unreadAlerts.length})
                </h2>

                <div className="space-y-2">
                  {unreadAlerts.map((alert: any) => {
                    const isUp = parseFloat(alert.newPrice) > parseFloat(alert.previousPrice);
                    const variation = parseFloat(alert.variationPercentage);

                    return (
                      <Card
                        key={alert.id}
                        className="bg-destructive/10 border-2 border-destructive p-4 rounded-lg"
                      >
                        <div className="flex justify-between items-start gap-2 mb-3">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground text-sm">
                              Produto #{alert.productId}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleDateString("pt-BR")}
                            </p>
                          </div>
                          <div className={`flex items-center gap-1 ${isUp ? "text-destructive" : "text-green-500"}`}>
                            {isUp ? (
                              <TrendingUp className="w-4 h-4" />
                            ) : (
                              <TrendingDown className="w-4 h-4" />
                            )}
                            <span className="font-bold text-sm">{variation.toFixed(1)}%</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 mb-3">
                          <div className="bg-card border border-border p-2 rounded">
                            <p className="text-xs text-muted-foreground">Preço Anterior</p>
                            <p className="font-semibold text-foreground">
                              R$ {parseFloat(alert.previousPrice).toFixed(2)}
                            </p>
                          </div>
                          <div className="bg-card border border-border p-2 rounded">
                            <p className="text-xs text-muted-foreground">Novo Preço</p>
                            <p className="font-semibold text-foreground">
                              R$ {parseFloat(alert.newPrice).toFixed(2)}
                            </p>
                          </div>
                        </div>

                        <Button
                          onClick={() => handleMarkAsRead(alert.id)}
                          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold py-2 rounded-lg border-2 border-accent text-sm"
                        >
                          MARCAR COMO LIDO
                        </Button>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Read Alerts */}
            {readAlerts.length > 0 && (
              <div>
                <h2 className="text-sm font-bold text-muted-foreground mb-3 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  ALERTAS LIDOS ({readAlerts.length})
                </h2>

                <div className="space-y-2">
                  {readAlerts.map((alert: any) => {
                    const isUp = parseFloat(alert.newPrice) > parseFloat(alert.previousPrice);
                    const variation = parseFloat(alert.variationPercentage);

                    return (
                      <Card
                        key={alert.id}
                        className="bg-card border-2 border-border p-4 rounded-lg opacity-75"
                      >
                        <div className="flex justify-between items-start gap-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground text-sm">
                              Produto #{alert.productId}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(alert.createdAt).toLocaleDateString("pt-BR")}
                            </p>
                          </div>
                          <div className={`flex items-center gap-1 text-sm ${isUp ? "text-destructive" : "text-green-500"}`}>
                            {isUp ? (
                              <TrendingUp className="w-4 h-4" />
                            ) : (
                              <TrendingDown className="w-4 h-4" />
                            )}
                            <span className="font-bold">{variation.toFixed(1)}%</span>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
