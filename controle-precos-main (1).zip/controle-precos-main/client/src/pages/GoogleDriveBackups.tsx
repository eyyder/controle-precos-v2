import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Cloud, Download, Trash2, Upload, RefreshCw } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function GoogleDriveBackups() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);

  const { data: localBackups = [] } = trpc.backup.list.useQuery();
  const { data: driveBackups = [], refetch: refetchDriveBackups } =
    trpc.backup.listGoogleDriveBackups.useQuery();

  const uploadMutation = trpc.backup.uploadToGoogleDrive.useMutation();
  const deleteMutation = trpc.backup.deleteGoogleDriveBackup.useMutation();

  const handleUploadBackup = async (filename: string) => {
    setIsLoading(true);
    try {
      const result = await uploadMutation.mutateAsync({ filename });
      if (result.success) {
        toast.success(`Backup enviado para Google Drive: ${filename}`);
        refetchDriveBackups();
      } else {
        toast.error("Erro ao enviar backup");
      }
    } catch (error) {
      toast.error("Erro ao enviar backup");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteBackup = async (fileId: string) => {
    if (!confirm("Tem certeza que deseja deletar este backup?")) return;

    try {
      const result = await deleteMutation.mutateAsync({ fileId });
      if (result.success) {
        toast.success("Backup deletado com sucesso");
        refetchDriveBackups();
      } else {
        toast.error("Erro ao deletar backup");
      }
    } catch (error) {
      toast.error("Erro ao deletar backup");
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b-2 border-accent sticky top-0 z-40">
        <div className="container max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/backups")}
              className="text-accent hover:bg-muted"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
                <Cloud className="w-6 h-6 text-accent" />
                GOOGLE DRIVE
              </h1>
              <p className="text-xs text-muted-foreground">Gerenciar backups na nuvem</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-4xl mx-auto px-4 py-6">
        {/* Local Backups to Upload */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5 text-accent" />
            BACKUPS LOCAIS PARA ENVIAR
          </h2>

          {localBackups.length === 0 ? (
            <Card className="bg-card border-2 border-accent p-6 rounded-lg text-center">
              <p className="text-foreground">Nenhum backup local disponível</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {localBackups.map((backup) => (
                <Card
                  key={backup.filename}
                  className="bg-card border-2 border-accent p-4 rounded-lg"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">{backup.filename}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(backup.timestamp).toLocaleString("pt-BR")} • {(backup.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                    <Button
                      onClick={() => handleUploadBackup(backup.filename)}
                      disabled={isLoading}
                      className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg border-2 border-accent"
                      size="sm"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      ENVIAR
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Google Drive Backups */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
              <Cloud className="w-5 h-5 text-accent" />
              BACKUPS NO GOOGLE DRIVE
            </h2>
            <Button
              onClick={() => refetchDriveBackups()}
              variant="outline"
              size="sm"
              className="border-2 border-accent text-foreground hover:bg-muted rounded-lg"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>

          {driveBackups.length === 0 ? (
            <Card className="bg-card border-2 border-accent p-6 rounded-lg text-center">
              <p className="text-foreground mb-2">Nenhum backup no Google Drive</p>
              <p className="text-sm text-muted-foreground">
                Envie um backup local para começar a sincronizar com a nuvem
              </p>
            </Card>
          ) : (
            <div className="space-y-3">
              {driveBackups.map((backup) => (
                <Card
                  key={backup.id}
                  className="bg-card border-2 border-accent p-4 rounded-lg"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-semibold text-foreground">{backup.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(backup.createdTime).toLocaleString("pt-BR")} • {(parseInt(backup.size) / 1024).toFixed(2)} KB
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => window.open(backup.webViewLink, "_blank")}
                        variant="outline"
                        size="sm"
                        className="border-2 border-accent text-foreground hover:bg-muted rounded-lg"
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => handleDeleteBackup(backup.id)}
                        variant="destructive"
                        size="sm"
                        className="bg-red-600 hover:bg-red-700 text-white rounded-lg border-2 border-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Info Box */}
        <Card className="bg-card border-2 border-accent p-4 rounded-lg mt-8">
          <p className="text-sm text-muted-foreground">
            <strong className="text-foreground">💡 Dica:</strong> Os backups são criados automaticamente todos os dias às 2:00 AM e sincronizados com o Google Drive. Você também pode fazer upload manual de qualquer backup local.
          </p>
        </Card>
      </div>
    </div>
  );
}
