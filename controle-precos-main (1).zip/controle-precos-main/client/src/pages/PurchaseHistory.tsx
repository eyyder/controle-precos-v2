import { useLocation } from "wouter";
import { ArrowLeft, ShoppingCart } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function PurchaseHistory() {
  const [, setLocation] = useLocation();
  const { data: history = [] } = trpc.purchaseHistory.listAll.useQuery();
  const { data: allProducts = [] } = trpc.products.list.useQuery();

  // Mapa de id -> nome do produto para exibição rápida
  const productMap = (allProducts as Array<{ id: number; name: string; variation?: string | null }>)
    .reduce<Record<number, { name: string; variation?: string | null }>>((acc, p) => {
      acc[p.id] = { name: p.name, variation: p.variation };
      return acc;
    }, {});

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const groupedByDate = (history as any[]).reduce<Record<string, any[]>>((acc, record) => {
    const date = new Date(record.purchaseDate).toLocaleDateString("pt-BR");
    if (!acc[date]) acc[date] = [];
    acc[date].push(record);
    return acc;
  }, {});

  const sortedDates = Object.keys(groupedByDate).sort((a, b) => {
    const dateA = new Date(a.split("/").reverse().join("-"));
    const dateB = new Date(b.split("/").reverse().join("-"));
    return dateB.getTime() - dateA.getTime();
  });

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => setLocation("/")}
            className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-base font-bold text-foreground">HISTÓRICO DE COMPRAS</h1>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5">
        {history.length === 0 ? (
          <div className="text-center py-16">
            <ShoppingCart className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-foreground font-semibold mb-1">Nenhuma compra registrada</p>
            <p className="text-muted-foreground text-sm">
              Registre compras na página de cada produto
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {sortedDates.map((date) => (
              <div key={date}>
                <h2 className="text-xs font-bold text-accent mb-3 flex items-center gap-2 uppercase tracking-wide">
                  <span className="w-2 h-2 bg-accent rounded-full inline-block"></span>
                  {date}
                </h2>

                <div className="space-y-2">
                  {groupedByDate[date].map((record: any) => {
                    const prod = productMap[record.productId];
                    const cost = parseFloat(record.costPrice);
                    const total = cost * record.quantity;

                    return (
                      <button
                        key={record.id}
                        onClick={() => setLocation(`/produto/${record.productId}`)}
                        className="w-full bg-card border border-accent/20 hover:border-accent rounded-xl p-4 text-left transition-all active:scale-[0.98]"
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-foreground text-sm leading-tight">
                              {prod ? prod.name : `Produto #${record.productId}`}
                            </p>
                            {prod?.variation && (
                              <p className="text-xs text-muted-foreground mt-0.5">{prod.variation}</p>
                            )}
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className="text-sm font-bold text-accent">R$ {cost.toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">× {record.quantity}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground">
                          <span>Total: <span className="font-semibold text-foreground">R$ {total.toFixed(2)}</span></span>
                          <div className="flex items-center gap-2">
                            {record.notes && (
                              <span className="text-accent/80 italic truncate max-w-[120px]">{record.notes}</span>
                            )}
                            <span>{new Date(record.purchaseDate).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</span>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
