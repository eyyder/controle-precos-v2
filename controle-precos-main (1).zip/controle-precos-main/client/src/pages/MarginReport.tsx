import { useMemo } from "react";
import { ArrowLeft, Download, TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { evaluateMargin, type MarginLevel } from "@/lib/marginEvaluator";
import * as XLSX from "xlsx";
import { toast } from "sonner";

// Categorias conhecidas do avaliador (mesmas do marginEvaluator)
const CATEGORY_LABELS: { keywords: string[]; label: string }[] = [
  { keywords: ["arroz", "feijao", "feijão", "macarrao", "macarrão", "farinha", "acucar", "açúcar", "açucar", "sal", "oleo", "óleo", "azeite"], label: "Cesta Básica / Grãos" },
  { keywords: ["leite", "iogurte", "queijo", "manteiga", "creme", "requeijao", "requeijão", "nata"], label: "Laticínios" },
  { keywords: ["refrigerante", "coca", "pepsi", "guarana", "guaraná", "fanta", "sprite", "soda", "agua", "água", "suco"], label: "Bebidas / Refrigerantes" },
  { keywords: ["cerveja", "skol", "brahma", "heineken", "itaipava", "budweiser", "eisenbahn", "chopp"], label: "Cervejas" },
  { keywords: ["frango", "carne", "boi", "porco", "peixe", "linguica", "linguiça", "salsicha", "presunto", "mortadela"], label: "Carnes / Frios" },
  { keywords: ["biscoito", "bolacha", "pao", "pão", "bolo", "torrada", "wafer", "cream cracker"], label: "Padaria / Biscoitos" },
  { keywords: ["chocolate", "bala", "balas", "pirulito", "chiclete", "drops", "caramelo", "bombom", "trident", "halls"], label: "Chocolates / Balas" },
  { keywords: ["salgadinho", "batata frita", "chips", "doritos", "ruffles", "cheetos", "amendoim", "castanha"], label: "Salgadinhos" },
  { keywords: ["cafe", "café", "nescafe", "nescafé", "cappuccino", "cha", "chá", "achocolatado", "nescau", "toddy", "ovomaltine"], label: "Café / Achocolatados" },
  { keywords: ["detergente", "sabao", "sabão", "amaciante", "desinfetante", "multiuso", "limpeza", "ajax", "omo", "ariel", "downy", "comfort"], label: "Limpeza" },
  { keywords: ["shampoo", "condicionador", "sabonete", "creme dental", "pasta de dente", "escova", "fio dental", "desodorante", "absorvente"], label: "Higiene Pessoal" },
  { keywords: ["fraldas", "fralda", "lenco", "lenço", "papel higienico", "papel higiênico", "guardanapo", "papel toalha"], label: "Descartáveis" },
];

function normalize(text: string): string {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s]/g, " ").trim();
}

function detectCategoryLabel(name: string): string {
  const n = normalize(name);
  for (const cat of CATEGORY_LABELS) {
    for (const kw of cat.keywords) {
      if (n.includes(normalize(kw))) return cat.label;
    }
  }
  return "Outros";
}

interface CategoryStat {
  label: string;
  count: number;
  avgMargin: number;
  minMargin: number;
  maxMargin: number;
  criticalCount: number;
  lowCount: number;
  okCount: number;
  goodCount: number;
  products: { name: string; variation?: string | null; margin: number; level: MarginLevel; costPrice: number; sellingPrice: number }[];
}

const LEVEL_ORDER: MarginLevel[] = ["critical", "low", "acceptable", "good"];

function LevelIcon({ level }: { level: MarginLevel }) {
  switch (level) {
    case "critical": return <XCircle className="w-4 h-4 text-red-500" />;
    case "low":      return <AlertTriangle className="w-4 h-4 text-orange-400" />;
    case "acceptable":  return <TrendingUp className="w-4 h-4 text-yellow-400" />;
    case "good":     return <CheckCircle2 className="w-4 h-4 text-green-500" />;
  }
}

function levelLabel(level: MarginLevel) {
  switch (level) {
    case "critical": return "Crítica";
    case "low":      return "Baixa";
    case "acceptable": return "Aceitável";
    case "good":     return "Boa";
  }
}

export default function MarginReport() {
  const [, setLocation] = useLocation();
  const { data: products = [] } = trpc.products.list.useQuery();

  const stats = useMemo((): CategoryStat[] => {
    const map: Record<string, CategoryStat> = {};

    (products as any[]).forEach((p) => {
      const cost = parseFloat(p.costPrice || "0");
      const selling = parseFloat(p.sellingPrice || "0");
      if (cost <= 0 || selling <= 0) return;

      const margin = ((selling - cost) / selling) * 100;
      const ev = evaluateMargin(cost, selling);
      const label = detectCategoryLabel(p.name);

      if (!map[label]) {
        map[label] = { label, count: 0, avgMargin: 0, minMargin: Infinity, maxMargin: -Infinity, criticalCount: 0, lowCount: 0, okCount: 0, goodCount: 0, products: [] };
      }

      const cat = map[label];
      cat.count++;
      cat.avgMargin += margin;
      cat.minMargin = Math.min(cat.minMargin, margin);
      cat.maxMargin = Math.max(cat.maxMargin, margin);
      if (ev.level === "critical") cat.criticalCount++;
      else if (ev.level === "low") cat.lowCount++;
      else if (ev.level === "acceptable") cat.okCount++;
      else cat.goodCount++;
      cat.products.push({ name: p.name, variation: p.variation, margin, level: ev.level, costPrice: cost, sellingPrice: selling });
    });

    // Calcular média
    Object.values(map).forEach((cat) => {
      cat.avgMargin = cat.avgMargin / cat.count;
      // Ordenar produtos por margem crescente (piores primeiro)
      cat.products.sort((a, b) => a.margin - b.margin);
    });

    // Ordenar categorias: primeiro as com mais problemas
    return Object.values(map).sort((a, b) => {
      const aProblems = a.criticalCount * 3 + a.lowCount;
      const bProblems = b.criticalCount * 3 + b.lowCount;
      return bProblems - aProblems || a.label.localeCompare(b.label);
    });
  }, [products]);

  const totals = useMemo(() => {
    const total = stats.reduce((acc, c) => ({
      count: acc.count + c.count,
      critical: acc.critical + c.criticalCount,
      low: acc.low + c.lowCount,
      ok: acc.ok + c.okCount,
      good: acc.good + c.goodCount,
    }), { count: 0, critical: 0, low: 0, ok: 0, good: 0 });
    return total;
  }, [stats]);

  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const handleExportExcel = () => {
    try {
      // Aba 1: Resumo por categoria
      const summaryData = stats.map((cat) => ({
        "Categoria": cat.label,
        "Qtd Produtos": cat.count,
        "Margem Média": `${cat.avgMargin.toFixed(1)}%`,
        "Margem Mín.": `${cat.minMargin.toFixed(1)}%`,
        "Margem Máx.": `${cat.maxMargin.toFixed(1)}%`,
        "Críticos": cat.criticalCount,
        "Baixos": cat.lowCount,
        "Aceitáveis": cat.okCount,
        "Bons": cat.goodCount,
      }));

      // Aba 2: Detalhe de produtos com problema
      const problemData: any[] = [];
      stats.forEach((cat) => {
        cat.products
          .filter((p) => p.level === "critical" || p.level === "low")
          .forEach((p) => {
            problemData.push({
              "Categoria": cat.label,
              "Produto": p.name,
              "Variação": p.variation || "-",
              "Custo (R$)": p.costPrice.toFixed(2),
              "Venda (R$)": p.sellingPrice.toFixed(2),
              "Margem Atual": `${p.margin.toFixed(1)}%`,
              "Status": levelLabel(p.level),
            });
          });
      });

      const wb = XLSX.utils.book_new();

      const ws1 = XLSX.utils.json_to_sheet(summaryData);
      ws1["!cols"] = [20, 14, 14, 14, 14, 10, 10, 12, 10].map((w) => ({ wch: w }));
      XLSX.utils.book_append_sheet(wb, ws1, "Resumo por Categoria");

      if (problemData.length > 0) {
        const ws2 = XLSX.utils.json_to_sheet(problemData);
        ws2["!cols"] = [20, 28, 12, 12, 12, 14, 12].map((w) => ({ wch: w }));
        XLSX.utils.book_append_sheet(wb, ws2, "Produtos com Problema");
      }

      XLSX.writeFile(wb, `relatorio-margens-${new Date().toISOString().split("T")[0]}.xlsx`);
      toast.success("Relatório Excel exportado com sucesso!");
    } catch {
      toast.error("Erro ao exportar relatório");
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => setLocation("/")}
            className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="font-bold text-foreground text-base">Relatório de Margem</h1>
            <p className="text-xs text-muted-foreground">por categoria de produto</p>
          </div>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-2 bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl px-4 py-2 text-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            Excel
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* Cards de resumo geral */}
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-card border border-accent/30 rounded-xl p-3 text-center">
            <p className="text-xl font-bold text-foreground">{totals.count}</p>
            <p className="text-[10px] text-muted-foreground uppercase">Total</p>
          </div>
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 text-center">
            <p className="text-xl font-bold text-red-500">{totals.critical}</p>
            <p className="text-[10px] text-muted-foreground uppercase">Críticos</p>
          </div>
          <div className="bg-orange-400/10 border border-orange-400/30 rounded-xl p-3 text-center">
            <p className="text-xl font-bold text-orange-400">{totals.low}</p>
            <p className="text-[10px] text-muted-foreground uppercase">Baixos</p>
          </div>
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-3 text-center">
            <p className="text-xl font-bold text-green-500">{totals.good}</p>
            <p className="text-[10px] text-muted-foreground uppercase">Bons</p>
          </div>
        </div>

        {/* Lista por categoria */}
        {stats.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>Nenhum produto cadastrado ainda.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {stats.map((cat) => {
              const hasProblems = cat.criticalCount > 0 || cat.lowCount > 0;
              const isExpanded = expandedCategory === cat.label;

              return (
                <div
                  key={cat.label}
                  className={`bg-card border rounded-2xl overflow-hidden transition-all ${
                    cat.criticalCount > 0
                      ? "border-red-500/40"
                      : cat.lowCount > 0
                      ? "border-orange-400/40"
                      : "border-accent/30"
                  }`}
                >
                  {/* Cabeçalho da categoria */}
                  <button
                    onClick={() => setExpandedCategory(isExpanded ? null : cat.label)}
                    className="w-full px-4 py-4 flex items-center gap-3 text-left"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-bold text-foreground text-sm">{cat.label}</p>
                        {cat.criticalCount > 0 && (
                          <span className="text-[10px] font-bold bg-red-500/15 text-red-500 px-1.5 py-0.5 rounded-md">
                            {cat.criticalCount} crítico{cat.criticalCount !== 1 ? "s" : ""}
                          </span>
                        )}
                        {cat.lowCount > 0 && (
                          <span className="text-[10px] font-bold bg-orange-400/15 text-orange-400 px-1.5 py-0.5 rounded-md">
                            {cat.lowCount} baixo{cat.lowCount !== 1 ? "s" : ""}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{cat.count} produto{cat.count !== 1 ? "s" : ""}</p>
                    </div>

                    {/* Margem média */}
                    <div className="text-right flex-shrink-0">
                      <p className={`text-lg font-bold ${
                        cat.avgMargin >= 30 ? "text-green-500" : cat.avgMargin >= 20 ? "text-yellow-400" : "text-orange-400"
                      }`}>
                        {cat.avgMargin.toFixed(1)}%
                      </p>
                      <p className="text-[10px] text-muted-foreground">média</p>
                    </div>

                    <span className="text-muted-foreground text-sm ml-1">{isExpanded ? "▲" : "▼"}</span>
                  </button>

                  {/* Barra de distribuição */}
                  <div className="px-4 pb-3">
                    <div className="flex h-2 rounded-full overflow-hidden gap-0.5">
                      {cat.criticalCount > 0 && (
                        <div
                          className="bg-red-500 rounded-full"
                          style={{ width: `${(cat.criticalCount / cat.count) * 100}%` }}
                        />
                      )}
                      {cat.lowCount > 0 && (
                        <div
                          className="bg-orange-400 rounded-full"
                          style={{ width: `${(cat.lowCount / cat.count) * 100}%` }}
                        />
                      )}
                      {cat.okCount > 0 && (
                        <div
                          className="bg-yellow-400 rounded-full"
                          style={{ width: `${(cat.okCount / cat.count) * 100}%` }}
                        />
                      )}
                      {cat.goodCount > 0 && (
                        <div
                          className="bg-green-500 rounded-full"
                          style={{ width: `${(cat.goodCount / cat.count) * 100}%` }}
                        />
                      )}
                    </div>
                    <div className="flex gap-3 mt-1.5 flex-wrap">
                      {cat.criticalCount > 0 && <span className="text-[10px] text-red-500">{cat.criticalCount} crítico{cat.criticalCount !== 1 ? "s" : ""}</span>}
                      {cat.lowCount > 0 && <span className="text-[10px] text-orange-400">{cat.lowCount} baixo{cat.lowCount !== 1 ? "s" : ""}</span>}
                      {cat.okCount > 0 && <span className="text-[10px] text-yellow-400">{cat.okCount} aceitável{cat.okCount !== 1 ? "is" : ""}</span>}
                      {cat.goodCount > 0 && <span className="text-[10px] text-green-500">{cat.goodCount} bom{cat.goodCount !== 1 ? "ns" : ""}</span>}
                    </div>
                  </div>

                  {/* Lista de produtos (expandida) */}
                  {isExpanded && (
                    <div className="border-t border-accent/20 divide-y divide-accent/10">
                      {cat.products.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            // Navegar para o produto (precisamos do ID, mas aqui temos só o nome)
                            // Vamos apenas fechar o expand
                          }}
                          className="w-full px-4 py-3 flex items-center gap-3 text-left hover:bg-accent/5 transition-colors"
                        >
                          <LevelIcon level={p.level} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                            {p.variation && <p className="text-xs text-muted-foreground">{p.variation}</p>}
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className={`text-sm font-bold ${
                              p.level === "critical" ? "text-red-500" :
                              p.level === "low" ? "text-orange-400" :
                              p.level === "acceptable" ? "text-yellow-400" : "text-green-500"
                            }`}>{p.margin.toFixed(1)}%</p>
                            <p className="text-[10px] text-muted-foreground">{levelLabel(p.level)}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Legenda */}
        <div className="bg-card border border-accent/20 rounded-xl p-4">
          <p className="text-xs font-bold text-muted-foreground uppercase mb-3">Legenda</p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-2"><XCircle className="w-4 h-4 text-red-500" /><span className="text-muted-foreground">Crítica — abaixo de 70% do mínimo</span></div>
            <div className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-orange-400" /><span className="text-muted-foreground">Baixa — abaixo do mínimo SEBRAE</span></div>
            <div className="flex items-center gap-2"><TrendingUp className="w-4 h-4 text-yellow-400" /><span className="text-muted-foreground">Aceitável — entre mínimo e ideal</span></div>
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" /><span className="text-muted-foreground">Boa — acima da margem ideal</span></div>
          </div>
          <p className="text-[10px] text-muted-foreground mt-3">Referências: SEBRAE, ABRAS, CNC — Varejo Alimentar</p>
        </div>
      </div>
    </div>
  );
}

// Importação necessária para o useState
import { useState } from "react";
