import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Download, Trash2, Plus, Loader2, HardDrive, Cloud } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function Backups() {
  const [, setLocation] = useLocation();
  const [isCreating, setIsCreating] = useState(false);
  const [isDownloading, setIsDownloading] = useState<string | null>(null);

  const { data: backups = [], refetch: refetchBackups } = trpc.backup.list.useQuery();
  const { data: stats } = trpc.backup.stats.useQuery();
  const deleteMutation = trpc.backup.delete.useMutation();
  const createMutation = trpc.backup.createManual.useMutation();

  const handleCreateBackup = async () => {
    setIsCreating(true);
    try {
      await createMutation.mutateAsync();
      toast.success("Backup criado com sucesso!");
      refetchBackups();
    } catch (error) {
      toast.error("Erro ao criar backup");
      console.error(error);
    } finally {
      setIsCreating(false);
    }
  };

  const handleDownloadBackup = async (filename: string) => {
    setIsDownloading(filename);
    try {
      const response = await fetch(`/api/backup/download/${encodeURIComponent(filename)}`);

      if (!response.ok) {
        toast.error("Erro ao baixar backup");
        return;
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success("Backup baixado com sucesso!");
    } catch (error) {
      toast.error("Erro ao baixar backup");
      console.error(error);
    } finally {
      setIsDownloading(null);
    }
  };

  const handleDeleteBackup = async (filename: string) => {
    try {
      await deleteMutation.mutateAsync({ filename });
      toast.success("Backup deletado com sucesso!");
      refetchBackups();
    } catch (error) {
      toast.error("Erro ao deletar backup");
      console.error(error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("pt-BR");
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <button
            onClick={() => setLocation("/")}
            className="p-2 hover:bg-accent/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-2xl md:text-3xl font-bold">GERENCIAR BACKUPS</h1>
        </div>

        <div className="border-b-2 border-accent mb-6" />

        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card className="bg-card border-2 border-accent rounded-lg p-4">
              <div className="text-sm text-muted-foreground mb-1">Total de Backups</div>
              <div className="text-3xl font-bold text-accent">{stats.totalBackups}</div>
            </Card>
            <Card className="bg-card border-2 border-accent rounded-lg p-4">
              <div className="text-sm text-muted-foreground mb-1">Espaço Usado</div>
              <div className="text-3xl font-bold text-accent">{formatFileSize(stats.totalSize)}</div>
            </Card>
            <Card className="bg-card border-2 border-accent rounded-lg p-4">
              <div className="text-sm text-muted-foreground mb-1">Último Backup</div>
              <div className="text-sm font-bold text-accent">
                {stats.newestBackup ? formatDate(stats.newestBackup) : "Nenhum"}
              </div>
            </Card>
          </div>
        )}

        <div className="space-y-3 mb-6">
          <Button
            onClick={handleCreateBackup}
            disabled={isCreating}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg border-2 border-accent py-6 text-lg"
          >
            {isCreating ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Criando Backup...
              </>
            ) : (
              <>
                <Plus className="w-5 h-5 mr-2" />
                CRIAR BACKUP AGORA
              </>
            )}
          </Button>

          <Button
            onClick={() => setLocation("/google-drive-backups")}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg border-2 border-blue-500 py-6 text-lg"
          >
            <Cloud className="w-5 h-5 mr-2" />
            GERENCIAR GOOGLE DRIVE
          </Button>
        </div>

        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <HardDrive className="w-5 h-5" />
          BACKUPS LOCAIS
        </h2>

        {backups.length === 0 ? (
          <Card className="bg-card border-2 border-accent rounded-lg p-6 text-center">
            <p className="text-muted-foreground">Nenhum backup encontrado</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {backups.map((backup) => (
              <Card
                key={backup.filename}
                className="bg-card border-2 border-accent rounded-lg p-4 flex items-center justify-between"
              >
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{backup.filename}</h3>
                  <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                    <span>{formatDate(backup.timestamp)}</span>
                    <span>{formatFileSize(backup.size)}</span>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <Button
                    onClick={() => handleDownloadBackup(backup.filename)}
                    disabled={isDownloading === backup.filename}
                    size="sm"
                    className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg border border-accent"
                  >
                    {isDownloading === backup.filename ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-destructive border-destructive hover:bg-destructive/10 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-2 border-accent rounded-lg">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-foreground">
                          Deletar Backup?
                        </AlertDialogTitle>
                        <AlertDialogDescription className="text-muted-foreground">
                          Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <div className="flex gap-3">
                        <AlertDialogCancel className="rounded-lg">Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDeleteBackup(backup.filename)}
                          className="bg-destructive hover:bg-destructive/90 text-white rounded-lg"
                        >
                          Deletar
                        </AlertDialogAction>
                      </div>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            ))}
          </div>
        )}

        <Card className="bg-card border-2 border-accent rounded-lg p-4 mt-6">
          <h3 className="font-bold text-foreground mb-2">ℹ️ Informações</h3>
          <p className="text-sm text-muted-foreground">
            Backups automáticos são criados diariamente às 2:00 AM. Você pode fazer download de
            qualquer backup para salvar em seu dispositivo ou enviar para o Google Drive.
          </p>
        </Card>
      </div>
    </div>
  );
}
