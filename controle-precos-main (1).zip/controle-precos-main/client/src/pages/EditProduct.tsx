import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sparkles, TrendingUp, Loader2 } from "lucide-react";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { toast } from "sonner";

export default function EditProduct() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const productId = parseInt(id || "0");

  const { data: product } = trpc.products.getById.useQuery({ id: productId });
  const { data: history = [] } = trpc.purchaseHistory.listByProduct.useQuery({ productId });
  const updateMutation = trpc.products.update.useMutation();

  const [name, setName] = useState("");
  const [variation, setVariation] = useState("");
  const [costPrice, setCostPrice] = useState("");
  const [sellingPrice, setSellingPrice] = useState("");
  const [quantity, setQuantity] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [suggestionApplied, setSuggestionApplied] = useState(false);
  const nameDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [debouncedName, setDebouncedName] = useState("");

  // Preencher formulário com dados do produto
  useEffect(() => {
    if (product) {
      setName(product.name || "");
      setVariation(product.variation || "");
      setCostPrice(parseFloat(product.costPrice?.toString() || "0").toFixed(2));
      setSellingPrice(parseFloat(product.sellingPrice?.toString() || "0").toFixed(2));
      setQuantity(product.currentQuantity?.toString() || "0");
      setDebouncedName(product.name || "");
    }
  }, [product]);

  // Debounce para atualizar sugestão quando o nome mudar
  useEffect(() => {
    if (nameDebounceRef.current) clearTimeout(nameDebounceRef.current);
    nameDebounceRef.current = setTimeout(() => {
      setDebouncedName(name);
      setSuggestionApplied(false);
    }, 500);
    return () => {
      if (nameDebounceRef.current) clearTimeout(nameDebounceRef.current);
    };
  }, [name]);

  // Busca sugestão de margem baseada no nome
  const { data: suggestion } = trpc.suggestedMargins.suggest.useQuery(
    { productName: debouncedName },
    { enabled: debouncedName.length >= 3 }
  );

  // Calcula preço de venda sugerido com base na margem
  const suggestedSellingPrice = suggestion && costPrice && parseFloat(costPrice) > 0
    ? (parseFloat(costPrice) / (1 - parseFloat(suggestion.suggestedMargin.toString()) / 100)).toFixed(2)
    : null;

  const applySuggestion = () => {
    if (suggestedSellingPrice) {
      setSellingPrice(suggestedSellingPrice);
      setSuggestionApplied(true);
    }
  };

  // Margem atual calculada em tempo real
  const currentMargin = costPrice && sellingPrice && parseFloat(sellingPrice) > 0
    ? ((parseFloat(sellingPrice) - parseFloat(costPrice)) / parseFloat(sellingPrice)) * 100
    : null;

  const minCostFromHistory = history.length > 0
    ? Math.min(...history.map((h) => parseFloat(h.costPrice.toString())))
    : product ? parseFloat(product.costPrice.toString()) : 0;
  const maxCostFromHistory = history.length > 0
    ? Math.max(...history.map((h) => parseFloat(h.costPrice.toString())))
    : product ? parseFloat(product.costPrice.toString()) : 0;

  const handleSave = async () => {
    if (!name || !costPrice || !sellingPrice) {
      toast.error("Preencha nome, preço de custo e preço de venda");
      return;
    }
    setIsLoading(true);
    try {
      await updateMutation.mutateAsync({
        id: productId,
        name,
        variation: variation || undefined,
        costPrice: parseFloat(costPrice),
        sellingPrice: parseFloat(sellingPrice),
        currentQuantity: quantity ? parseInt(quantity) : 0,
      });
      toast.success("Produto atualizado!");
      setLocation(`/produto/${productId}`);
    } catch {
      toast.error("Erro ao atualizar produto");
    } finally {
      setIsLoading(false);
    }
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => setLocation(`/produto/${productId}`)}
            className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-bold text-foreground truncate">EDITAR PRODUTO</h1>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* Nome — agora editável */}
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Nome do Produto *</label>
          <Input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Coca-Cola, Detergente, Biscoito..."
            className="bg-card border-2 border-accent/30 focus:border-accent rounded-xl px-4 py-4 text-base text-foreground"
          />
        </div>

        {/* Variação — agora editável */}
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Variação (opcional)</label>
          <Input
            type="text"
            value={variation}
            onChange={(e) => setVariation(e.target.value)}
            placeholder="Ex: 1L, 600ml, 500g, Pacote..."
            className="bg-card border border-accent/20 rounded-xl px-4 py-3 text-base text-foreground"
          />
        </div>

        {/* Sugestão de margem — aparece assim que o nome tiver 3+ caracteres */}
        {suggestion && name.length >= 3 && (
          <div className={`rounded-2xl border-2 p-4 transition-all ${
            suggestionApplied
              ? "bg-green-500/10 border-green-500/40"
              : "bg-accent/10 border-accent/40"
          }`}>
            <div className="flex items-start gap-3">
              <Sparkles className={`w-5 h-5 flex-shrink-0 mt-0.5 ${suggestionApplied ? "text-green-500" : "text-accent"}`} />
              <div className="flex-1">
                <p className={`text-sm font-bold mb-0.5 ${suggestionApplied ? "text-green-500" : "text-accent"}`}>
                  {suggestionApplied ? "✓ Sugestão aplicada!" : `Categoria detectada: ${suggestion.categoryName}`}
                </p>
                {suggestion.description && (
                  <p className="text-xs text-muted-foreground mb-3">{suggestion.description}</p>
                )}
                <div className="flex items-center gap-3 flex-wrap">
                  <div className="bg-background rounded-xl px-3 py-2 text-center">
                    <p className="text-[10px] text-muted-foreground uppercase mb-0.5">Margem sugerida</p>
                    <p className="text-base font-bold text-accent">{parseFloat(suggestion.suggestedMargin.toString()).toFixed(0)}%</p>
                  </div>
                  {suggestedSellingPrice ? (
                    <div className="bg-background rounded-xl px-3 py-2 text-center">
                      <p className="text-[10px] text-muted-foreground uppercase mb-0.5">Venda sugerida</p>
                      <p className="text-base font-bold text-foreground">R$ {suggestedSellingPrice}</p>
                    </div>
                  ) : (
                    <div className="bg-background/50 rounded-xl px-3 py-2 text-center border border-dashed border-accent/30">
                      <p className="text-[10px] text-muted-foreground uppercase mb-0.5">Venda sugerida</p>
                      <p className="text-xs text-muted-foreground">preencha o custo</p>
                    </div>
                  )}
                  {!suggestionApplied && suggestedSellingPrice && (
                    <button
                      onClick={applySuggestion}
                      className="flex items-center gap-1.5 bg-accent text-accent-foreground rounded-xl px-4 py-2 text-sm font-bold hover:bg-accent/90 transition-colors"
                    >
                      <TrendingUp className="w-4 h-4" />
                      Usar sugestão
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Preço de Custo */}
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Preço de Custo (R$)</label>
          <Input
            type="number"
            inputMode="decimal"
            step="0.01"
            value={costPrice}
            onChange={(e) => { setCostPrice(e.target.value); setSuggestionApplied(false); }}
            className="bg-card border-2 border-accent/30 focus:border-accent rounded-xl px-4 py-4 text-xl font-bold text-foreground"
          />
        </div>

        {/* Preço de Venda */}
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Preço de Venda (R$)</label>
          <Input
            type="number"
            inputMode="decimal"
            step="0.01"
            value={sellingPrice}
            onChange={(e) => { setSellingPrice(e.target.value); setSuggestionApplied(false); }}
            className="bg-card border-2 border-accent/30 focus:border-accent rounded-xl px-4 py-4 text-xl font-bold text-foreground"
          />
        </div>

        {/* Margem calculada em tempo real */}
        {currentMargin !== null && (
          <div className={`rounded-xl px-4 py-3 flex items-center justify-between border ${
            currentMargin >= 20
              ? "bg-green-500/10 border-green-500/30"
              : currentMargin >= 10
              ? "bg-yellow-500/10 border-yellow-500/30"
              : "bg-destructive/10 border-destructive/30"
          }`}>
            <span className="text-sm text-muted-foreground">Margem calculada</span>
            <span className={`text-xl font-bold ${
              currentMargin >= 20 ? "text-green-500" : currentMargin >= 10 ? "text-yellow-500" : "text-destructive"
            }`}>
              {currentMargin.toFixed(1)}%
            </span>
          </div>
        )}

        {/* Histórico de preço já pago */}
        <div className="rounded-xl border border-accent/20 bg-background/70 p-3">
          <p className="text-xs font-semibold text-muted-foreground mb-1">Histórico de custo (compra)</p>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-muted-foreground text-[11px]">Mínimo</p>
              <p className="font-bold text-foreground">R$ {minCostFromHistory.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[11px]">Máximo</p>
              <p className="font-bold text-foreground">R$ {maxCostFromHistory.toFixed(2)}</p>
            </div>
          </div>
        </div>

        {/* Quantidade */}
        <div>
          <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Quantidade em Estoque</label>
          <Input
            type="number"
            inputMode="numeric"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            className="bg-card border border-accent/20 rounded-xl px-4 py-3 text-base text-foreground"
          />
        </div>

        {/* Botões */}
        <div className="pt-2 space-y-2">
          <Button
            onClick={handleSave}
            disabled={isLoading || !name || !costPrice || !sellingPrice}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl py-6 text-base"
          >
            {isLoading ? "Salvando..." : "SALVAR ALTERAÇÕES"}
          </Button>
          <Button
            onClick={() => setLocation(`/produto/${productId}`)}
            variant="outline"
            className="w-full rounded-xl py-5 font-semibold"
          >
            Cancelar
          </Button>
        </div>
      </div>
    </div>
  );
}
