import { useAuth } from "@/_core/hooks/useAuth";
import MarginWarning from "@/components/MarginWarning";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, TrendingUp, TrendingDown, Trash2, Edit, ShoppingCart, Minus, Copy } from "lucide-react";
import { useParams as useWouterParams, useLocation as useWouterLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function ProductDetail() {
  const { id } = useWouterParams();
  const [, setLocation] = useWouterLocation();
  const productId = parseInt(id || "0");
  const { isAuthenticated } = useAuth();

  const { data: product, refetch } = trpc.products.getById.useQuery({ id: productId });
  const { data: history = [] } = trpc.purchaseHistory.listByProduct.useQuery({ productId });

  const [quantity, setQuantity] = useState("1");
  const [newCostPrice, setNewCostPrice] = useState("");
  const [notes, setNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  // Estado para clonar produto
  const [showCloneDialog, setShowCloneDialog] = useState(false);
  const [cloneName, setCloneName] = useState("");
  const [cloneVariation, setCloneVariation] = useState("");
  const [isCloningLoading, setIsCloningLoading] = useState(false);

  const createProductMutation = trpc.products.create.useMutation();
  const updateProductMutation = trpc.products.update.useMutation();
  const deleteProductMutation = trpc.products.delete.useMutation();

  const handleDeleteProduct = async () => {
    try {
      await deleteProductMutation.mutateAsync({ id: productId });
      toast.success("Produto excluído!");
      setLocation("/");
    } catch {
      toast.error("Erro ao excluir produto");
    }
  };

  const handleRegisterPurchase = async () => {
    if (!newCostPrice) {
      toast.error("Informe o preço de custo");
      return;
    }
    setIsLoading(true);
    try {
      const cost = parseFloat(newCostPrice);
      const currentSelling = parseFloat(product?.sellingPrice || "0");

      await createPurchaseMutation.mutateAsync({
        productId,
        costPrice: cost,
        sellingPrice: currentSelling,
        quantity: parseInt(quantity) || 1,
        purchaseDate: new Date(),
        notes: notes || undefined,
      });

      await updateProductMutation.mutateAsync({
        id: productId,
        costPrice: cost,
        sellingPrice: currentSelling,
      });

      toast.success("Compra registrada!");
      setNewCostPrice("");
      setQuantity("1");
      setNotes("");
      refetch();
    } catch {
      toast.error("Erro ao registrar compra");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCloneProduct = async () => {
    if (!cloneName.trim()) {
      toast.error("Informe o nome do produto clonado");
      return;
    }
    if (!product) return;
    setIsCloningLoading(true);
    try {
      const newProduct = await createProductMutation.mutateAsync({
        name: cloneName.trim(),
        variation: cloneVariation.trim() || undefined,
        costPrice: parseFloat(product.costPrice.toString()),
        sellingPrice: parseFloat(product.sellingPrice.toString()),
        currentQuantity: 0,
      });
      toast.success(`"${cloneName}" criado com sucesso!`);
      setShowCloneDialog(false);
      // Navegar para o novo produto
      if (newProduct?.id) {
        setLocation(`/produto/${newProduct.id}`);
      }
    } catch {
      toast.error("Erro ao clonar produto");
    } finally {
      setIsCloningLoading(false);
    }
  };

  const openCloneDialog = () => {
    if (!product) return;
    // Pré-preencher com o nome do produto atual + "Cópia"
    setCloneName(product.name + " (cópia)");
    setCloneVariation(product.variation || "");
    setShowCloneDialog(true);
  };

  const createPurchaseMutation = trpc.purchaseHistory.create.useMutation();

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Carregando produto...</p>
      </div>
    );
  }

  const currentCost = parseFloat(product.costPrice.toString());
  const currentSelling = parseFloat(product.sellingPrice.toString());
  const lastCost = product.lastCostPrice ? parseFloat(product.lastCostPrice.toString()) : null;
  const minCostFromHistory = product.minCostPrice ? parseFloat(product.minCostPrice.toString()) : currentCost;
  const maxCostFromHistory = product.maxCostPrice ? parseFloat(product.maxCostPrice.toString()) : currentCost;
  const margin = currentSelling > 0 ? ((currentSelling - currentCost) / currentSelling) * 100 : 0;

  // Variação do preço atual vs. anterior
  const priceVariation = lastCost && lastCost !== currentCost
    ? ((currentCost - lastCost) / lastCost) * 100
    : null;

  // Comparação em tempo real: novo preço digitado vs. preço atual
  const typedCost = newCostPrice ? parseFloat(newCostPrice) : null;
  const liveVariation = typedCost && currentCost > 0
    ? ((typedCost - currentCost) / currentCost) * 100
    : null;

  // Margem projetada com o novo preço
  const projectedMargin = typedCost && currentSelling > 0
    ? ((currentSelling - typedCost) / currentSelling) * 100
    : null;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center gap-3">
          <button
            onClick={() => setLocation("/")}
            className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-bold text-foreground text-base leading-tight truncate">{product.name}</h1>
            {product.variation && (
              <p className="text-xs text-muted-foreground">{product.variation}</p>
            )}
          </div>
          {/* Botão Clonar */}
          {isAuthenticated && (
            <button
              onClick={openCloneDialog}
              className="p-2 text-muted-foreground hover:text-accent hover:bg-accent/10 rounded-lg transition-colors"
              title="Clonar produto"
            >
              <Copy className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setLocation(`/edit-product/${productId}`)}
            className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
          >
            <Edit className="w-4 h-4" />
          </button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                <Trash2 className="w-4 h-4" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Excluir Produto?</AlertDialogTitle>
                <AlertDialogDescription>
                  Tem certeza que deseja excluir "{product.name}"? Esta ação não pode ser desfeita.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="flex gap-2 justify-end">
                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleDeleteProduct}
                  className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
                >
                  Excluir
                </AlertDialogAction>
              </div>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Dialog de Clonar Produto */}
      {showCloneDialog && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-card border border-accent/30 rounded-2xl w-full max-w-md p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center">
                <Copy className="w-5 h-5 text-accent" />
              </div>
              <div>
                <h2 className="text-base font-bold text-foreground">Clonar Produto</h2>
                <p className="text-xs text-muted-foreground">Copia preços de "{product.name}"</p>
              </div>
            </div>

            <div className="bg-accent/5 border border-accent/20 rounded-xl p-3 text-xs text-muted-foreground">
              Os preços de custo (R$ {currentCost.toFixed(2)}) e venda (R$ {currentSelling.toFixed(2)}) serão copiados. Você pode editar depois.
            </div>

            <div>
              <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Nome do novo produto *</label>
              <Input
                type="text"
                value={cloneName}
                onChange={(e) => setCloneName(e.target.value)}
                placeholder="Ex: Café Pilão, Café Melitta..."
                className="bg-background border-2 border-accent/30 focus:border-accent rounded-xl px-4 py-3 text-base text-foreground"
                autoFocus
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Variação (opcional)</label>
              <Input
                type="text"
                value={cloneVariation}
                onChange={(e) => setCloneVariation(e.target.value)}
                placeholder="Ex: 500g, 1kg, 250g..."
                className="bg-background border border-accent/20 rounded-xl px-4 py-3 text-sm text-foreground"
              />
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={handleCloneProduct}
                disabled={isCloningLoading || !cloneName.trim()}
                className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl py-3 text-sm disabled:opacity-50 transition-colors"
              >
                {isCloningLoading ? "Criando..." : "CRIAR CLONE"}
              </button>
              <button
                onClick={() => setShowCloneDialog(false)}
                className="px-5 bg-muted hover:bg-muted/80 text-foreground font-semibold rounded-xl py-3 text-sm transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* Cards de preço atuais */}
        <div className="grid grid-cols-3 gap-3">
          {/* Custo atual */}
          <div className="bg-card border border-accent/30 rounded-xl p-3 text-center">
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">Custo</p>
            <p className="text-lg font-bold text-foreground">R$ {currentCost.toFixed(2)}</p>
            {priceVariation !== null && (
              <div className={`flex items-center justify-center gap-0.5 mt-1 text-[10px] font-bold ${
                priceVariation > 0 ? "text-destructive" : "text-green-500"
              }`}>
                {priceVariation > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {priceVariation > 0 ? "+" : ""}{priceVariation.toFixed(1)}%
              </div>
            )}
          </div>

          {/* Venda atual */}
          <div className="bg-accent/10 border border-accent/40 rounded-xl p-3 text-center">
            <p className="text-[10px] text-accent uppercase font-semibold mb-1">Venda</p>
            <p className="text-lg font-bold text-accent">R$ {currentSelling.toFixed(2)}</p>
          </div>

          {/* Margem */}
          <div className={`rounded-xl p-3 text-center border ${
            margin >= 20
              ? "bg-green-500/10 border-green-500/30"
              : margin >= 10
              ? "bg-yellow-500/10 border-yellow-500/30"
              : "bg-destructive/10 border-destructive/30"
          }`}>
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">Margem</p>
            <p className={`text-lg font-bold ${
              margin >= 20 ? "text-green-500" : margin >= 10 ? "text-yellow-500" : "text-destructive"
            }`}>{margin.toFixed(1)}%</p>
          </div>
        </div>

        {/* Mín/Máx histórico de custo */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-background/80 border border-accent/20 rounded-xl p-3 text-center">
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">Mín. já pago</p>
            <p className="text-lg font-bold text-foreground">R$ {minCostFromHistory.toFixed(2)}</p>
          </div>
          <div className="bg-background/80 border border-accent/20 rounded-xl p-3 text-center">
            <p className="text-[10px] text-muted-foreground uppercase font-semibold mb-1">Máx. já pago</p>
            <p className="text-lg font-bold text-foreground">R$ {maxCostFromHistory.toFixed(2)}</p>
          </div>
        </div>

        {/* Alerta de margem abaixo do recomendado */}
        <MarginWarning
          productName={product.name}
          costPrice={currentCost}
          sellingPrice={currentSelling}
        />

        {/* Preço anterior */}
        {lastCost && (
          <div className="bg-muted/50 rounded-xl px-4 py-2.5 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Preço anterior:</span>
            <span className="text-sm font-semibold text-foreground">R$ {lastCost.toFixed(2)}</span>
          </div>
        )}

        {/* ===== REGISTRAR NOVA COMPRA ===== */}
        <div className="bg-card border border-accent/30 rounded-2xl p-5">
          <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-accent" />
            REGISTRAR COMPRA NO ATACADO
          </h2>

          {/* Novo preço de custo — campo principal */}
          <div className="mb-3">
            <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">
              Preço de Custo Novo (R$)
            </label>
            <Input
              type="number"
              inputMode="decimal"
              step="0.01"
              value={newCostPrice}
              onChange={(e) => setNewCostPrice(e.target.value)}
              placeholder={`Atual: R$ ${currentCost.toFixed(2)}`}
              className="w-full bg-background border-2 border-accent rounded-xl px-4 py-4 text-xl font-bold text-foreground placeholder:text-muted-foreground/50 focus:ring-2 focus:ring-accent/50"
            />
          </div>

          {/* Comparação em tempo real */}
          {liveVariation !== null && (
            <div className={`rounded-xl p-4 mb-3 border-2 ${
              liveVariation > 5
                ? "bg-destructive/10 border-destructive/40"
                : liveVariation < -5
                ? "bg-green-500/10 border-green-500/40"
                : "bg-yellow-500/10 border-yellow-500/40"
            }`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-muted-foreground uppercase">Variação vs. preço atual</span>
                <div className={`flex items-center gap-1 text-base font-bold ${
                  liveVariation > 5 ? "text-destructive" : liveVariation < -5 ? "text-green-500" : "text-yellow-500"
                }`}>
                  {liveVariation > 0.5 ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : liveVariation < -0.5 ? (
                    <TrendingDown className="w-4 h-4" />
                  ) : (
                    <Minus className="w-4 h-4" />
                  )}
                  {liveVariation > 0 ? "+" : ""}{liveVariation.toFixed(1)}%
                </div>
              </div>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>
                  {liveVariation > 5
                    ? "⚠️ Ficou mais caro"
                    : liveVariation < -5
                    ? "✅ Ficou mais barato"
                    : "Preço praticamente igual"}
                </span>
                {projectedMargin !== null && (
                  <span className={`font-semibold ${
                    projectedMargin >= 20 ? "text-green-500" : projectedMargin >= 10 ? "text-yellow-500" : "text-destructive"
                  }`}>
                    Margem: {projectedMargin.toFixed(1)}%
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Quantidade */}
          <div className="mb-3">
            <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Quantidade</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setQuantity(String(Math.max(1, parseInt(quantity || "1") - 1)))}
                className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-xl font-bold text-foreground hover:bg-muted/80"
              >
                −
              </button>
              <Input
                type="number"
                inputMode="numeric"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                className="flex-1 text-center text-xl font-bold bg-background border-2 border-accent/30 rounded-xl py-3"
              />
              <button
                onClick={() => setQuantity(String(parseInt(quantity || "0") + 1))}
                className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-xl font-bold text-foreground hover:bg-muted/80"
              >
                +
              </button>
            </div>
          </div>

          {/* Observações */}
          <div className="mb-4">
            <label className="block text-xs font-bold text-muted-foreground mb-2 uppercase">Observação (opcional)</label>
            <Input
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: promoção, fornecedor diferente..."
              className="w-full bg-background border border-accent/30 rounded-xl px-4 py-3 text-sm text-foreground"
            />
          </div>

          <button
            onClick={handleRegisterPurchase}
            disabled={isLoading || !newCostPrice}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl py-4 text-base disabled:opacity-50 transition-colors"
          >
            {isLoading ? "Registrando..." : "REGISTRAR COMPRA"}
          </button>
        </div>

        {/* Histórico de compras */}
        <div className="bg-card border border-accent/30 rounded-2xl overflow-hidden">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="w-full flex items-center justify-between px-5 py-4"
          >
            <span className="text-sm font-bold text-foreground">
              HISTÓRICO ({history.length} compras)
            </span>
            <span className="text-muted-foreground text-sm">{showHistory ? "▲" : "▼"}</span>
          </button>

          {showHistory && history.length > 0 && (
            <div className="border-t border-accent/20 divide-y divide-accent/10">
              {history.map((record, idx) => {
                const recordCost = parseFloat(record.costPrice.toString());
                return (
                  <div key={idx} className="px-5 py-3 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        R$ {recordCost.toFixed(2)}
                        <span className="text-muted-foreground font-normal ml-2">× {record.quantity}</span>
                      </p>
                      {record.notes && (
                        <p className="text-xs text-muted-foreground mt-0.5">{record.notes}</p>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {new Date(record.purchaseDate).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                );
              })}
            </div>
          )}

          {showHistory && history.length === 0 && (
            <div className="border-t border-accent/20 px-5 py-6 text-center text-muted-foreground text-sm">
              Nenhuma compra registrada ainda
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
