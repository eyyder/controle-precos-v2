import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Plus, Trash2, Sparkles, Edit2, Check, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

export default function SuggestedMargins() {
  const [, setLocation] = useLocation();
  const { data: margins = [], refetch } = trpc.suggestedMargins.list.useQuery();

  const upsertMutation = trpc.suggestedMargins.upsert.useMutation();
  const deleteMutation = trpc.suggestedMargins.delete.useMutation();

  // Estado para nova categoria
  const [showForm, setShowForm] = useState(false);
  const [newCategory, setNewCategory] = useState("");
  const [newMargin, setNewMargin] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newKeywords, setNewKeywords] = useState("");

  // Estado para edição inline
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editMargin, setEditMargin] = useState("");
  const [editDescription, setEditDescription] = useState("");

  const handleAdd = async () => {
    if (!newCategory || !newMargin) {
      toast.error("Preencha o nome da categoria e a margem");
      return;
    }
    try {
      await upsertMutation.mutateAsync({
        categoryName: newCategory,
        suggestedMargin: parseFloat(newMargin),
        description: newDescription || undefined,
        keywords: newKeywords || undefined,
      });
      toast.success("Categoria adicionada!");
      setNewCategory("");
      setNewMargin("");
      setNewDescription("");
      setNewKeywords("");
      setShowForm(false);
      refetch();
    } catch {
      toast.error("Erro ao adicionar categoria");
    }
  };

  const handleDelete = async (id: number, name: string) => {
    if (!confirm(`Excluir a categoria "${name}"?`)) return;
    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Categoria removida!");
      refetch();
    } catch {
      toast.error("Erro ao remover categoria");
    }
  };

  const startEdit = (margin: { id: number; suggestedMargin: string; description?: string | null }) => {
    setEditingId(margin.id);
    setEditMargin(parseFloat(margin.suggestedMargin.toString()).toFixed(0));
    setEditDescription(margin.description || "");
  };

  const saveEdit = async (categoryName: string) => {
    if (!editMargin) return;
    try {
      await upsertMutation.mutateAsync({
        categoryName,
        suggestedMargin: parseFloat(editMargin),
        description: editDescription || undefined,
      });
      toast.success("Margem atualizada!");
      setEditingId(null);
      refetch();
    } catch {
      toast.error("Erro ao atualizar margem");
    }
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setLocation("/")}
              className="p-2 text-accent hover:bg-accent/10 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-base font-bold text-foreground">MARGENS SUGERIDAS</h1>
              <p className="text-xs text-muted-foreground">{margins.length} categorias configuradas</p>
            </div>
          </div>
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 bg-accent text-accent-foreground rounded-xl px-4 py-2 text-sm font-bold hover:bg-accent/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Nova
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-5 space-y-4">
        {/* Explicação */}
        <div className="bg-accent/10 border border-accent/30 rounded-2xl p-4">
          <div className="flex gap-3">
            <Sparkles className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-foreground mb-1">Como funciona?</p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Ao cadastrar um produto, o sistema detecta automaticamente a categoria pelo nome e sugere o preço de venda ideal. Por exemplo: digitar "Coca-Cola" sugere margem de 30% (Refrigerantes).
              </p>
            </div>
          </div>
        </div>

        {/* Formulário de nova categoria */}
        {showForm && (
          <div className="bg-card border-2 border-accent/40 rounded-2xl p-5 space-y-3">
            <h2 className="text-sm font-bold text-foreground">NOVA CATEGORIA</h2>
            <div>
              <label className="block text-xs text-muted-foreground mb-1 uppercase font-semibold">Nome da Categoria *</label>
              <Input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Ex: Bebidas Energéticas"
                className="bg-background border border-accent/30 rounded-xl px-4 py-3 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1 uppercase font-semibold">Margem Sugerida (%) *</label>
              <Input
                type="number"
                inputMode="decimal"
                value={newMargin}
                onChange={(e) => setNewMargin(e.target.value)}
                placeholder="Ex: 45"
                className="bg-background border border-accent/30 rounded-xl px-4 py-3 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1 uppercase font-semibold">Descrição / Dica (opcional)</label>
              <Input
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                placeholder="Ex: Produtos de impulso com alta rotatividade"
                className="bg-background border border-accent/30 rounded-xl px-4 py-3 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1 uppercase font-semibold">
                Palavras-chave (separadas por vírgula)
              </label>
              <Input
                value={newKeywords}
                onChange={(e) => setNewKeywords(e.target.value)}
                placeholder="Ex: red bull, monster, energético, energy"
                className="bg-background border border-accent/30 rounded-xl px-4 py-3 text-sm"
              />
              <p className="text-[10px] text-muted-foreground mt-1">
                Usadas para detectar automaticamente a categoria pelo nome do produto
              </p>
            </div>
            <div className="flex gap-2 pt-1">
              <Button
                onClick={handleAdd}
                disabled={upsertMutation.isPending}
                className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-xl py-3"
              >
                {upsertMutation.isPending ? "Salvando..." : "ADICIONAR"}
              </Button>
              <Button
                onClick={() => setShowForm(false)}
                variant="outline"
                className="rounded-xl py-3 px-4"
              >
                Cancelar
              </Button>
            </div>
          </div>
        )}

        {/* Lista de categorias */}
        <div className="space-y-2">
          {(margins as Array<{
            id: number;
            categoryName: string;
            suggestedMargin: string;
            description?: string | null;
            keywords?: string | null;
          }>).map((margin) => (
            <div
              key={margin.id}
              className="bg-card border border-accent/20 rounded-xl p-4"
            >
              {editingId === margin.id ? (
                // Modo edição
                <div className="space-y-3">
                  <p className="text-sm font-bold text-foreground">{margin.categoryName}</p>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="block text-[10px] text-muted-foreground mb-1 uppercase">Margem (%)</label>
                      <Input
                        type="number"
                        value={editMargin}
                        onChange={(e) => setEditMargin(e.target.value)}
                        className="bg-background border border-accent/30 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                    <div className="flex-[2]">
                      <label className="block text-[10px] text-muted-foreground mb-1 uppercase">Descrição</label>
                      <Input
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        className="bg-background border border-accent/30 rounded-lg px-3 py-2 text-sm"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => saveEdit(margin.categoryName)}
                      className="flex items-center gap-1.5 bg-green-500 text-white rounded-lg px-3 py-2 text-xs font-bold"
                    >
                      <Check className="w-3.5 h-3.5" /> Salvar
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="flex items-center gap-1.5 bg-muted text-foreground rounded-lg px-3 py-2 text-xs font-bold"
                    >
                      <X className="w-3.5 h-3.5" /> Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                // Modo visualização
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center flex-shrink-0">
                    <span className="text-accent font-bold text-sm">
                      {parseFloat(margin.suggestedMargin.toString()).toFixed(0)}%
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm">{margin.categoryName}</p>
                    {margin.description && (
                      <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{margin.description}</p>
                    )}
                    {margin.keywords && (
                      <p className="text-[10px] text-accent/60 mt-1 truncate">
                        🔑 {margin.keywords.split(",").slice(0, 5).join(", ")}
                        {margin.keywords.split(",").length > 5 ? "..." : ""}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-1 flex-shrink-0">
                    <button
                      onClick={() => startEdit(margin)}
                      className="p-2 text-muted-foreground hover:text-accent hover:bg-accent/10 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(margin.id, margin.categoryName)}
                      className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
