import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Download, Search, TrendingUp, TrendingDown } from "lucide-react";
import MarginWarning from "@/components/MarginWarning";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

export default function ProductsList() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"name" | "margin" | "minPrice" | "maxPrice">("name");

  const { data: products = [] } = trpc.products.listWithStats.useQuery();

  const filteredAndSorted = useMemo(() => {
    let filtered = products.filter((p: any) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.variation && p.variation.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    filtered.sort((a: any, b: any) => {
      switch (sortBy) {
        case "margin":
          return (b.marginValue || 0) - (a.marginValue || 0);
        case "minPrice":
          return (a.minCostPrice || 0) - (b.minCostPrice || 0);
        case "maxPrice":
          return (b.maxCostPrice || 0) - (a.maxCostPrice || 0);
        case "name":
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return filtered;
  }, [products, searchTerm, sortBy]);

  const handleExportExcel = () => {
    try {
      const data = filteredAndSorted.map((p: any) => ({
        "Produto": p.name,
        "Variação": p.variation || "-",
        "Preço Mín. (Custo)": `R$ ${(p.minCostPrice || 0).toFixed(2)}`,
        "Preço Máx. (Custo)": `R$ ${(p.maxCostPrice || 0).toFixed(2)}`,
        "Último Preço": `R$ ${(p.lastCostPriceValue || 0).toFixed(2)}`,
        "Preço Venda": `R$ ${parseFloat(p.sellingPrice).toFixed(2)}`,
        "Margem de Lucro": `${(p.marginValue || 0).toFixed(1)}%`,
        "Quantidade": p.currentQuantity || 0,
        "Última Compra": new Date(p.lastPurchaseDate).toLocaleDateString("pt-BR"),
      }));

      const worksheet = XLSX.utils.json_to_sheet(data);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Produtos");

      // Ajustar largura das colunas
      const colWidths = [25, 15, 18, 18, 18, 15, 18, 12, 15];
      worksheet["!cols"] = colWidths.map(w => ({ wch: w }));

      XLSX.writeFile(workbook, `produtos-${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success("Arquivo Excel exportado com sucesso!");
    } catch (error) {
      toast.error("Erro ao exportar arquivo Excel");
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b-2 border-accent sticky top-0 z-40">
        <div className="container max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4 mb-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-accent hover:bg-muted"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground">LISTAGEM DE PRODUTOS</h1>
              <p className="text-xs text-muted-foreground">
                {filteredAndSorted.length} produto(s) encontrado(s)
              </p>
            </div>
          </div>

          {/* Search and Export */}
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Buscar produto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-background border-2 border-accent text-foreground placeholder:text-muted-foreground rounded-lg"
              />
            </div>
            <Button
              onClick={handleExportExcel}
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-lg border-2 border-accent flex items-center gap-2"
              size="sm"
            >
              <Download className="w-4 h-4" />
              EXCEL
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-4xl mx-auto px-4 py-6">
        {/* Sort Options */}
        <div className="flex gap-2 mb-6 flex-wrap">
          <Button
            onClick={() => setSortBy("name")}
            variant={sortBy === "name" ? "default" : "outline"}
            size="sm"
            className={`rounded-lg border-2 ${
              sortBy === "name"
                ? "bg-accent border-accent text-accent-foreground"
                : "border-accent text-foreground hover:bg-muted"
            }`}
          >
            Nome
          </Button>
          <Button
            onClick={() => setSortBy("margin")}
            variant={sortBy === "margin" ? "default" : "outline"}
            size="sm"
            className={`rounded-lg border-2 ${
              sortBy === "margin"
                ? "bg-accent border-accent text-accent-foreground"
                : "border-accent text-foreground hover:bg-muted"
            }`}
          >
            Margem
          </Button>
          <Button
            onClick={() => setSortBy("minPrice")}
            variant={sortBy === "minPrice" ? "default" : "outline"}
            size="sm"
            className={`rounded-lg border-2 ${
              sortBy === "minPrice"
                ? "bg-accent border-accent text-accent-foreground"
                : "border-accent text-foreground hover:bg-muted"
            }`}
          >
            Preço Mín.
          </Button>
          <Button
            onClick={() => setSortBy("maxPrice")}
            variant={sortBy === "maxPrice" ? "default" : "outline"}
            size="sm"
            className={`rounded-lg border-2 ${
              sortBy === "maxPrice"
                ? "bg-accent border-accent text-accent-foreground"
                : "border-accent text-foreground hover:bg-muted"
            }`}
          >
            Preço Máx.
          </Button>
        </div>

        {/* Products Table */}
        {filteredAndSorted.length === 0 ? (
          <Card className="bg-card border-2 border-accent p-6 rounded-lg text-center">
            <p className="text-foreground mb-2">Nenhum produto encontrado</p>
            <p className="text-sm text-muted-foreground">
              Tente ajustar seus filtros de busca
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredAndSorted.map((product: any) => {
              const margin = product.marginValue || 0;
              const isPositiveMargin = margin > 0;

              return (
                <Card
                  key={product.id}
                  onClick={() => setLocation(`/produto/${product.id}`)}
                  className="bg-card border-2 border-accent p-4 rounded-lg cursor-pointer hover:border-accent/80 transition-colors"
                >
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {/* Product Name */}
                    <div className="col-span-2 md:col-span-1">
                      <p className="text-xs text-muted-foreground mb-1">PRODUTO</p>
                      <p className="font-semibold text-foreground text-sm">{product.name}</p>
                      {product.variation && (
                        <p className="text-xs text-muted-foreground mt-1">{product.variation}</p>
                      )}
                    </div>

                    {/* Price Range */}
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">CUSTO</p>
                      <div className="space-y-1">
                        <p className="text-sm text-foreground">
                          Mín: <span className="font-semibold">R$ {(product.minCostPrice || 0).toFixed(2)}</span>
                        </p>
                        <p className="text-sm text-foreground">
                          Máx: <span className="font-semibold">R$ {(product.maxCostPrice || 0).toFixed(2)}</span>
                        </p>
                      </div>
                    </div>

                    {/* Last Price */}
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">ÚLTIMO PREÇO</p>
                      <p className="font-semibold text-foreground text-sm">
                        R$ {(product.lastCostPriceValue || 0).toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(product.lastPurchaseDate).toLocaleDateString("pt-BR")}
                      </p>
                    </div>

                    {/* Selling Price */}
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">VENDA</p>
                      <p className="font-semibold text-foreground text-sm">
                        R$ {parseFloat(product.sellingPrice || 0).toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Preço de venda</p>
                    </div>

                    {/* Margin */}
                    <div className="flex flex-col justify-between gap-1">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">MARGEM</p>
                        <div className="flex items-center gap-2">
                          {isPositiveMargin ? (
                            <TrendingUp className="w-4 h-4 text-green-500" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-500" />
                          )}
                          <span
                            className={`font-semibold text-sm ${
                              isPositiveMargin ? "text-green-500" : "text-red-500"
                            }`}
                          >
                            {margin.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <MarginWarning
                        productName={product.name}
                        costPrice={parseFloat(product.costPrice || "0")}
                        sellingPrice={parseFloat(product.sellingPrice || "0")}
                        compact
                      />
                      <p className="text-xs text-muted-foreground">
                        Qtd: {product.currentQuantity || 0}
                      </p>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
