import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, FileText, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState, useRef } from "react";
import { toast } from "sonner";

interface ProductRow {
  name: string;
  variation?: string;
  costPrice: number;
  sellingPrice: number;
  quantity?: number;
}

export default function ImportProducts() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [preview, setPreview] = useState<ProductRow[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createProductMutation = trpc.products.create.useMutation();

  const parseCSV = (text: string): ProductRow[] => {
    const lines = text.trim().split("\n");
    const products: ProductRow[] = [];

    // Skip header if present
    const startIndex = lines[0].toLowerCase().includes("nome") ? 1 : 0;

    for (let i = startIndex; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const parts = line.split(",").map((p) => p.trim());

      if (parts.length >= 3) {
        const product: ProductRow = {
          name: parts[0],
          variation: parts[1] && parts[1] !== "-" ? parts[1] : undefined,
          costPrice: parseFloat(parts[2]),
          sellingPrice: parseFloat(parts[3] || parts[2]),
          quantity: parts[4] ? parseInt(parts[4]) : 0,
        };

        if (product.name && !isNaN(product.costPrice) && !isNaN(product.sellingPrice)) {
          products.push(product);
        }
      }
    }

    return products;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const products = parseCSV(text);

        if (products.length === 0) {
          toast.error("Nenhum produto válido encontrado no arquivo");
          return;
        }

        setPreview(products);
        toast.success(`${products.length} produtos carregados para importação`);
      } catch (error) {
        toast.error("Erro ao processar arquivo");
        console.error(error);
      }
    };
    reader.readAsText(file);
  };

  const handleImport = async () => {
    if (preview.length === 0) {
      toast.error("Nenhum produto para importar");
      return;
    }

    setIsLoading(true);
    try {
      let successCount = 0;
      let errorCount = 0;

      for (const product of preview) {
        try {
          await createProductMutation.mutateAsync({
            name: product.name,
            variation: product.variation,
            costPrice: product.costPrice,
            sellingPrice: product.sellingPrice,
            currentQuantity: product.quantity || 0,
          });
          successCount++;
        } catch (error) {
          errorCount++;
          console.error(`Erro ao importar ${product.name}:`, error);
        }
      }

      toast.success(`${successCount} produtos importados com sucesso!`);
      if (errorCount > 0) {
        toast.error(`${errorCount} produtos falharam na importação`);
      }

      setPreview([]);
      setLocation("/");
    } catch (error) {
      toast.error("Erro ao importar produtos");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b-2 border-accent sticky top-0 z-40">
        <div className="container max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-accent hover:bg-muted"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-foreground">IMPORTAR PRODUTOS</h1>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        {/* Instructions */}
        <div className="bg-muted border-l-4 border-accent p-4 rounded-lg mb-6">
          <h2 className="font-semibold text-foreground mb-3 flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Formato do Arquivo
          </h2>
          <p className="text-sm text-muted-foreground mb-3">
            Use um arquivo CSV com as seguintes colunas:
          </p>
          <div className="bg-card p-3 rounded text-xs text-foreground font-mono space-y-1">
            <p>Nome,Variação,Preço Custo,Preço Venda,Quantidade</p>
            <p className="text-muted-foreground">Coca-Cola,1L,6.90,8.50,12</p>
            <p className="text-muted-foreground">Leite,1L,3.50,5.00,20</p>
            <p className="text-muted-foreground">Pão,Francês,0.50,1.00,100</p>
          </div>
        </div>

        {/* Upload Area */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-accent rounded-lg p-8 text-center cursor-pointer hover:bg-muted/50 transition-colors mb-6"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,.txt"
            onChange={handleFileUpload}
            className="hidden"
          />
          <Upload className="w-12 h-12 text-accent mx-auto mb-3" />
          <p className="text-foreground font-semibold mb-1">Clique para selecionar arquivo</p>
          <p className="text-sm text-muted-foreground">ou arraste um arquivo CSV aqui</p>
        </div>

        {/* Preview */}
        {preview.length > 0 && (
          <div className="mb-6">
            <h2 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-accent" />
              PRÉVIA ({preview.length} produtos)
            </h2>

            <div className="space-y-2 mb-6 max-h-96 overflow-y-auto">
              {preview.map((product, index) => (
                <div
                  key={index}
                  className="bg-card border-2 border-border p-3 rounded-lg text-sm"
                >
                  <div className="flex justify-between items-start gap-2 mb-1">
                    <div>
                      <p className="font-semibold text-foreground">
                        {product.name}
                        {product.variation && ` (${product.variation})`}
                      </p>
                    </div>
                    <p className="text-accent font-bold">
                      R$ {product.costPrice.toFixed(2)} → R$ {product.sellingPrice.toFixed(2)}
                    </p>
                  </div>
                  {product.quantity && (
                    <p className="text-xs text-muted-foreground">
                      Quantidade: {product.quantity}
                    </p>
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <Button
                onClick={handleImport}
                disabled={isLoading}
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold py-4 rounded-lg border-2 border-accent text-lg"
              >
                {isLoading ? "Importando..." : `IMPORTAR ${preview.length} PRODUTOS`}
              </Button>

              <Button
                onClick={() => {
                  setPreview([]);
                  if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                  }
                }}
                variant="outline"
                className="w-full text-foreground border-2 border-border hover:bg-muted py-4 rounded-lg font-semibold"
              >
                CANCELAR
              </Button>
            </div>
          </div>
        )}

        {/* Template Download */}
        <div className="bg-card border-2 border-border p-4 rounded-lg">
          <p className="text-sm text-muted-foreground mb-3">
            Precisa de um template? Copie o formato abaixo e salve como arquivo .csv:
          </p>
          <div className="bg-input p-3 rounded text-xs text-foreground font-mono overflow-x-auto">
            <pre>{`Nome,Variação,Preço Custo,Preço Venda,Quantidade
Coca-Cola,1L,6.90,8.50,12
Coca-Cola,600ml,4.50,6.00,15
Coca-Cola,350ml,2.50,3.50,20
Leite,1L,3.50,5.00,10
Pão,Francês,0.50,1.00,50`}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
