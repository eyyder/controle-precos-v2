import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, History, AlertCircle, Settings, List, Package, Sparkles, AlertTriangle, BarChart2 } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import QuickSearch from "@/components/QuickSearch";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { evaluateMargin } from "@/lib/marginEvaluator";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showTools, setShowTools] = useState(false);
  const { data: products = [] } = trpc.products.list.useQuery();
  const { data: unreadAlerts = [] } = trpc.priceAlerts.listUnread.useQuery();

  // Produtos com margem crítica ou abaixo do recomendado
  const criticalProducts = useMemo(() => {
    return (products as any[]).filter((p) => {
      const cost = parseFloat(p.costPrice || "0");
      const selling = parseFloat(p.sellingPrice || "0");
      if (cost <= 0 || selling <= 0) return false;
      const ev = evaluateMargin(cost, selling, p.name);
      return ev.level === "critical" || ev.level === "low";
    }).slice(0, 5); // Mostrar no máximo 5 na tela inicial
  }, [products]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-accent" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card border-2 border-accent rounded-2xl p-8">
            <div className="mb-8 text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-accent" />
              </div>
              <h1 className="text-3xl font-bold text-accent mb-1">Mercearia</h1>
              <h2 className="text-xl font-semibold text-foreground">Eyder de Preços</h2>
            </div>

            <p className="text-muted-foreground text-sm text-center mb-8 leading-relaxed">
              Consulte e atualize preços no supermercado em segundos. Acesso compartilhado para toda a equipe.
            </p>

            <a href={getLoginUrl()}>
              <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold py-6 text-lg rounded-xl">
                ENTRAR
              </Button>
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header compacto */}
      <div className="bg-card border-b border-accent/30 sticky top-0 z-40 px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div>
            <span className="text-accent font-bold text-lg">Mercearia</span>
            <span className="text-muted-foreground text-xs ml-2">Olá, {user?.name?.split(" ")[0] || "Usuário"}</span>
          </div>
          <div className="flex items-center gap-2">
            {unreadAlerts.length > 0 && (
              <button
                onClick={() => setLocation("/alertas")}
                className="relative p-2 text-destructive"
              >
                <AlertCircle className="w-5 h-5" />
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-destructive text-destructive-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
                  {unreadAlerts.length}
                </span>
              </button>
            )}
            <button
              onClick={() => setShowTools(!showTools)}
              className={`p-2 rounded-lg transition-colors ${showTools ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Menu de ferramentas (colapsável) */}
      {showTools && (
        <div className="bg-card border-b border-accent/30 px-4 py-3 z-30">
          <div className="max-w-2xl mx-auto">
            <p className="text-xs text-muted-foreground mb-3 font-semibold uppercase tracking-wide">Ferramentas</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setShowTools(false); setLocation("/novo-produto"); }}
                className="flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/20 transition-colors"
              >
                <Plus className="w-4 h-4 text-accent" />
                Novo Produto
              </button>
              <button
                onClick={() => { setShowTools(false); setLocation("/listagem"); }}
                className="flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/20 transition-colors"
              >
                <List className="w-4 h-4 text-accent" />
                Listagem
              </button>
              <button
                onClick={() => { setShowTools(false); setLocation("/margens-sugeridas"); }}
                className="flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/20 transition-colors"
              >
                <Sparkles className="w-4 h-4 text-accent" />
                Margens Sugeridas
              </button>
              <button
                onClick={() => { setShowTools(false); setLocation("/relatorio-margens"); }}
                className="flex items-center gap-2 bg-accent/10 border border-accent/30 rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/20 transition-colors"
              >
                <BarChart2 className="w-4 h-4 text-accent" />
                Relatório Margens
              </button>
              <button
                onClick={() => { setShowTools(false); setLocation("/importar"); }}
                className="flex items-center gap-2 bg-muted border border-border rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-muted/80 transition-colors"
              >
                <span className="text-accent">↑</span>
                Importar CSV
              </button>
              <button
                onClick={() => { setShowTools(false); setLocation("/backups"); }}
                className="flex items-center gap-2 bg-muted border border-border rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-muted/80 transition-colors"
              >
                <span className="text-accent">⬡</span>
                Backups
              </button>
              <button
                onClick={() => { setShowTools(false); window.location.href = "/api/pdf/report"; }}
                className="flex items-center gap-2 bg-muted border border-border rounded-xl px-4 py-3 text-sm font-semibold text-foreground hover:bg-muted/80 transition-colors col-span-2"
              >
                <span className="text-accent">↓</span>
                Baixar Relatório PDF
              </button>
              <button
                onClick={() => { setShowTools(false); logout(); }}
                className="flex items-center gap-2 bg-muted border border-border rounded-xl px-4 py-3 text-sm font-semibold text-muted-foreground hover:bg-muted/80 transition-colors col-span-2"
              >
                Sair da conta
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Área principal: busca + resultados */}
      <div className="flex-1 px-4 pt-5 pb-24 max-w-2xl mx-auto w-full">
        {/* Estatísticas rápidas */}
        <div className="flex gap-3 mb-5">
          <div className="flex-1 bg-card border border-accent/30 rounded-xl px-4 py-3 text-center">
            <div className="text-2xl font-bold text-accent">{products.length}</div>
            <div className="text-xs text-muted-foreground">Produtos</div>
          </div>
          {unreadAlerts.length > 0 && (
            <button
              onClick={() => setLocation("/alertas")}
              className="flex-1 bg-destructive/10 border border-destructive/40 rounded-xl px-4 py-3 text-center"
            >
              <div className="text-2xl font-bold text-destructive">{unreadAlerts.length}</div>
              <div className="text-xs text-destructive/80">Alertas</div>
            </button>
          )}
        </div>

        {/* Painel de Margem Crítica */}
        {criticalProducts.length > 0 && (
          <div className="mb-5">
            <button
              onClick={() => setLocation("/listagem")}
              className="w-full"
            >
              <div className="bg-orange-500/10 border border-orange-500/40 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-orange-400" />
                    <span className="text-sm font-bold text-orange-400 uppercase tracking-wide">
                      {criticalProducts.length} produto{criticalProducts.length !== 1 ? "s" : ""} com margem baixa
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">Ver todos ›</span>
                </div>
                <div className="space-y-2">
                  {criticalProducts.map((p: any) => {
                    const cost = parseFloat(p.costPrice || "0");
                    const selling = parseFloat(p.sellingPrice || "0");
                    const margin = selling > 0 ? ((selling - cost) / selling) * 100 : 0;
                    const ev = evaluateMargin(cost, selling, p.name);
                    return (
                      <div key={p.id} className="flex items-center justify-between bg-background/50 rounded-xl px-3 py-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-foreground truncate">{p.name}</p>
                          {p.variation && <p className="text-xs text-muted-foreground truncate">{p.variation}</p>}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                          <span className={`text-sm font-bold ${
                            ev.level === "critical" ? "text-red-500" : "text-orange-400"
                          }`}>{margin.toFixed(1)}%</span>
                          <span className="text-xs text-muted-foreground">/ mín {ev.minRecommended}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {products.length > 5 && (
                  <p className="text-xs text-muted-foreground text-center mt-2">Toque para ver todos na listagem</p>
                )}
              </div>
            </button>
          </div>
        )}

        {/* Busca principal — ocupa destaque */}
        <QuickSearch onSelectProduct={(id) => setLocation(`/produto/${id}`)} />
      </div>

      {/* Barra de navegação inferior */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-accent/30 z-40">
        <div className="max-w-2xl mx-auto flex">
          <button
            onClick={() => setLocation("/")}
            className="flex-1 flex flex-col items-center gap-1 py-3 text-accent"
          >
            <Package className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Buscar</span>
          </button>
          <button
            onClick={() => setLocation("/historico")}
            className="flex-1 flex flex-col items-center gap-1 py-3 text-muted-foreground hover:text-foreground transition-colors"
          >
            <History className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Histórico</span>
          </button>
          <button
            onClick={() => setLocation("/alertas")}
            className="flex-1 flex flex-col items-center gap-1 py-3 text-muted-foreground hover:text-foreground transition-colors relative"
          >
            <AlertCircle className="w-5 h-5" />
            {unreadAlerts.length > 0 && (
              <span className="absolute top-2 right-1/4 w-3.5 h-3.5 bg-destructive text-destructive-foreground text-[9px] font-bold rounded-full flex items-center justify-center">
                {unreadAlerts.length}
              </span>
            )}
            <span className="text-[10px] font-semibold">Alertas</span>
          </button>
          <button
            onClick={() => setLocation("/novo-produto")}
            className="flex-1 flex flex-col items-center gap-1 py-3 text-muted-foreground hover:text-foreground transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span className="text-[10px] font-semibold">Novo</span>
          </button>
        </div>
      </div>
    </div>
  );
}
