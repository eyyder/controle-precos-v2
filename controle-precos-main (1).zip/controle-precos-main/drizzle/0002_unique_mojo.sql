CREATE TABLE `suggestedMargins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`categoryName` varchar(100) NOT NULL,
	`suggestedMargin` decimal(5,2) NOT NULL,
	`description` text,
	`keywords` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suggestedMargins_id` PRIMARY KEY(`id`),
	CONSTRAINT `suggestedMargins_categoryName_unique` UNIQUE(`categoryName`)
);
