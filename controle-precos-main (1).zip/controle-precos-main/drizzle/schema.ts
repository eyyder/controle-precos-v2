import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Categorias de produtos para organização
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Produtos com preços de custo e venda
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  categoryId: int("categoryId"),
  variation: varchar("variation", { length: 100 }), // Ex: "1L", "600ml", "350ml"
  costPrice: decimal("costPrice", { precision: 10, scale: 2 }).notNull(),
  sellingPrice: decimal("sellingPrice", { precision: 10, scale: 2 }).notNull(),
  currentQuantity: int("currentQuantity").default(0),
  lastCostPrice: decimal("lastCostPrice", { precision: 10, scale: 2 }),
  lastPriceUpdateDate: timestamp("lastPriceUpdateDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Histórico de compras com data, preço e quantidade
 */
export const purchaseHistory = mysqlTable("purchaseHistory", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  costPrice: decimal("costPrice", { precision: 10, scale: 2 }).notNull(),
  sellingPrice: decimal("sellingPrice", { precision: 10, scale: 2 }),
  quantity: int("quantity").notNull(),
  purchaseDate: timestamp("purchaseDate").notNull(),
  userId: int("userId").notNull(), // Quem fez a compra
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PurchaseHistory = typeof purchaseHistory.$inferSelect;
export type InsertPurchaseHistory = typeof purchaseHistory.$inferInsert;

/**
 * Alertas de variação de preço
 */
export const priceAlerts = mysqlTable("priceAlerts", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  previousPrice: decimal("previousPrice", { precision: 10, scale: 2 }).notNull(),
  newPrice: decimal("newPrice", { precision: 10, scale: 2 }).notNull(),
  variationPercentage: decimal("variationPercentage", { precision: 5, scale: 2 }).notNull(),
  alertThreshold: decimal("alertThreshold", { precision: 5, scale: 2 }).default("10"), // Default 10%
  isRead: int("isRead").default(0), // 0 = false, 1 = true
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PriceAlert = typeof priceAlerts.$inferSelect;
export type InsertPriceAlert = typeof priceAlerts.$inferInsert;

/**
 * Margens sugeridas por categoria de produto
 * Permite configurar margens recomendadas para facilitar precificação
 */
export const suggestedMargins = mysqlTable("suggestedMargins", {
  id: int("id").autoincrement().primaryKey(),
  categoryName: varchar("categoryName", { length: 100 }).notNull().unique(),
  suggestedMargin: decimal("suggestedMargin", { precision: 5, scale: 2 }).notNull(), // Ex: 30.00 = 30%
  description: text("description"), // Dica ou justificativa
  keywords: text("keywords"), // Palavras-chave separadas por vírgula para matching automático
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SuggestedMargin = typeof suggestedMargins.$inferSelect;
export type InsertSuggestedMargin = typeof suggestedMargins.$inferInsert;